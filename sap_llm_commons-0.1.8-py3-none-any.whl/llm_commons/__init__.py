try:
    import pkg_resources
    __version__ = pkg_resources.require('sap-llm-commons')[0].version
except:  # pylint: disable=bare-except
    __version__ = 'unknown'
