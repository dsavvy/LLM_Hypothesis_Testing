import os

from .deprecation import surface_btp_llm_deprecation_warnings
from .identity import BTPProxyClient

surface_btp_llm_deprecation_warnings()

PREFIX = 'BTP_LLM'
BTP_LLM_DEFAULT_HOME = f'{os.path.expanduser("~")}/.btp_llm'

api_base = None
auth_url = None
client_id = None
client_secret = None
