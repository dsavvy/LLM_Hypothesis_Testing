import pathlib
from typing import Any

from .deprecation import warn_on_import

new_module = f'llm_commons.proxy.{pathlib.Path(__file__).stem}'

__all__ = ('BTPClient', )


def get_new_module(obj):
    return f'{new_module}.{obj.__name__}'


def __getattr__(name: str) -> Any:
    if name == 'BTPClient':
        from llm_commons.proxy.aleph_alpha import Client as client
        warn_on_import(name, get_new_module(client))
        return client
