import sys
import warnings
from typing import Optional


class BTPLLMDeprecationWarning(DeprecationWarning):
    """A class for issuing deprecation warnings for LangChain users."""


def surface_btp_llm_deprecation_warnings() -> None:
    """Unmute LangChain deprecation warnings."""
    warnings.filterwarnings(
        'default',
        category=BTPLLMDeprecationWarning,
    )


def deprecation_warning_once(msg):
    if not getattr(deprecation_warning_once, 'log', None):
        deprecation_warning_once.log = set()
    if msg not in deprecation_warning_once.log:
        warnings.warn(msg, BTPLLMDeprecationWarning, stacklevel=2)
        deprecation_warning_once.log.add(msg)


def warn_on_import(name: str, new_module_name: Optional[str] = None) -> None:
    """Warn on import of deprecated module."""
    if hasattr(sys, 'ps2'):
        # No warnings for interactive environments.
        # This is done to avoid polluting the output of interactive environments
        # where users rely on auto-complete and may trigger this warning
        # even if they are not using any deprecated modules
        return
    new_module_name = new_module_name or 'llm_commons.proxy'
    deprecation_warning_once(
        f"Importing {name} from btp_llm module is no longer supported. Use the '{new_module_name}' module instead.")
