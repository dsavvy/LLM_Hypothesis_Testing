import os
import pathlib
from dataclasses import dataclass
from functools import lru_cache, wraps
from http.client import HTTPException
from typing import Any, Dict, Optional
from warnings import warn

import requests

import llm_commons.btp_llm as btp_llm
from llm_commons.proxy.base import (
    BaseDeployment,
    CredentialsValue,
    PredictionURLs,
    ProxyClient,
    fetch_credentials,
    proxy_clients,
)
from llm_commons.proxy.identity import CACHE_TOKEN_TIMEOUT, _lru_cache_timeout
from llm_commons.proxy.vcap_services import VCAPEnvironment

CREDENTIAL_VALUES = [
    CredentialsValue(name='client_id', vcap_name='credentials.uaa.clientid'),
    CredentialsValue(name='client_secret', vcap_name='credentials.uaa.clientsecret'),
    CredentialsValue(name='auth_url', vcap_name='credentials.uaa.url'),
    CredentialsValue(name='api_base', vcap_name='credentials.url')
]


def get_token(auth_url=None, client_id=None, client_secret=None):
    """Get a token from XSUAA.
    :param auth_url: URL of the XSUAA service
    :param client_id: Client ID of the service instance
    :param client_secret: Client secret of the service instance
    :return: Access token
    """
    auth_url = auth_url or btp_llm.auth_url
    if not auth_url:
        raise ValueError(
            'Either explicitly provide a value for auth_url, set llm_commons.btp_llm.auth_url or use environment variable BTP_LLM_AUTH_URL'
        )
    client_id = client_id or btp_llm.client_id
    if not client_id:
        raise ValueError(
            'Either explicitly provide a value for client_id, set llm_commons.btp_llm.client_id or use environment variable BTP_LLM_CLIENT_ID'
        )
    client_secret = client_secret or btp_llm.client_secret
    if not client_secret:
        raise ValueError(
            'Either explicitly provide a value for client_secret, set llm_commons.btp_llm.client_secret or use environment variable BTP_LLM_CLIENT_SECRET'
        )

    data = {
        'grant_type': 'client_credentials',
        'client_id': client_id,
        'client_secret': client_secret,
    }
    response = requests.post(auth_url + '/oauth/token?grant_type=client_credentials', data=data, timeout=5)
    if response.status_code == 200:
        token_data = response.json()
        return token_data['access_token']
    raise HTTPException(f'status_code={response.status_code}, detail={response.text}')


COMPLETION_ENDPOINT = '/api/v1/completions'
EMBEDDINGS_ENDPOINT = '/api/v1/embeddings'

prediction_urls = PredictionURLs({
    'text-davinci-003': COMPLETION_ENDPOINT,
    'gpt-35-turbo': COMPLETION_ENDPOINT,
    'gpt-4-turbo': COMPLETION_ENDPOINT,
    'gpt-4': COMPLETION_ENDPOINT,
    'gpt-4-32k': COMPLETION_ENDPOINT,
    'gpt-35-turbo-16k': COMPLETION_ENDPOINT,
    'gpt-35-turbo-instruct': COMPLETION_ENDPOINT,
    'alephalpha': COMPLETION_ENDPOINT,
    'anthropic-claude-v1': COMPLETION_ENDPOINT,
    'anthropic-claude-v2': COMPLETION_ENDPOINT,
    'anthropic-claude-instant-v1': COMPLETION_ENDPOINT,
    'anthropic-claude-v1-100k': COMPLETION_ENDPOINT,
    'anthropic-claude-v2-100k': COMPLETION_ENDPOINT,
    'anthropic-direct': COMPLETION_ENDPOINT,
    'ai21-j2-grande-instruct': COMPLETION_ENDPOINT,
    'ai21-j2-jumbo-instruct': COMPLETION_ENDPOINT,
    'amazon-titan-tg1-large': COMPLETION_ENDPOINT,
    'gcp-text-bison-001': COMPLETION_ENDPOINT,
    'cohere-command': COMPLETION_ENDPOINT,
    'falcon-7b': COMPLETION_ENDPOINT,
    'falcon-40b-instruct': COMPLETION_ENDPOINT,
    'llama2-13b-chat-hf': COMPLETION_ENDPOINT,
    'llama2-70b-chat-hf': COMPLETION_ENDPOINT,
    'text-embedding-ada-002-v2': EMBEDDINGS_ENDPOINT,
    'amazon-titan-e1t-medium': EMBEDDINGS_ENDPOINT,
    'gcp-textembedding-gecko-001': EMBEDDINGS_ENDPOINT
})


@dataclass(frozen=True)
class BTPDeployment(BaseDeployment):
    model_identification_kwargs = ('deployment_id', )
    url: str
    deployment_id: str

    def __post_init__(self):
        if not isinstance(self.deployment_id, str) or not isinstance(self.url, str):
            raise ValueError("'deployment_id' and 'url' have to be of type str")

    @property
    def model_name(self):
        return self.deployment_id

    @property
    def prediction_url(self):
        return self.prediction_url_registry(self.model_name, self.url)

    def get_prediction_url_registry(self):
        return prediction_urls

    def additonal_request_body_kwargs(self) -> Dict[str, Any]:
        return {'deployment_id': self.deployment_id}


@proxy_clients.register('btp')
class BTPProxyClient(ProxyClient):
    deployment_class = BTPDeployment
    _registries = {}
    _refresh = True

    def __new__(cls,
                api_base: Optional[str] = None,
                auth_url: Optional[str] = None,
                client_id: Optional[str] = None,
                client_secret: Optional[str] = None,
                resource_group: Optional[str] = None):
        if cls._refresh:
            cls.refresh_credentials()
            cls._refresh = False
        key = (api_base, auth_url, client_id, client_secret)
        if cls._registries.get(key) is None:
            cls._registries[key] = super(BTPProxyClient, cls).__new__(cls)
        return cls._registries[key]

    def __init__(self,
                 api_base: Optional[str] = None,
                 auth_url: Optional[str] = None,
                 client_id: Optional[str] = None,
                 client_secret: Optional[str] = None,
                 resource_group: Optional[str] = None):
        if resource_group is not None:
            warn("You are using the BTP proxy so passing the keyword argument 'resource_group' has no effect.",
                 DeprecationWarning,
                 stacklevel=2)
        if hasattr(self, 'api_base'):
            return  # skip init when alreay exists
        self.api_base = api_base or btp_llm.api_base
        self.auth_url = auth_url or btp_llm.auth_url
        self.client_id = client_id or btp_llm.client_id
        self.client_secret = client_secret or btp_llm.client_secret

    def get_request_header(self):
        header = {}
        header.update({'Authorization': 'Bearer ' + self.get_token()})
        return header

    @_lru_cache_timeout(CACHE_TOKEN_TIMEOUT)
    def get_token(self):
        return get_token(self.auth_url, client_id=self.client_id, client_secret=self.client_secret)

    @lru_cache
    def get_deployment(self, deployment_id, **kwargs):
        if len([v for v in kwargs.values() if v is not None]) > 0:
            warn("You are using the BTP proxy 'deployment_id' is the only parameter to retrieve a deployment.",
                 DeprecationWarning,
                 stacklevel=2)
        return BTPDeployment(url=self.api_base, deployment_id=deployment_id)

    def get_deployments(self):
        return [self.get_deployment(id_) for id_ in prediction_urls._suffixes.keys()]

    def update_deployments(self):
        self.get_deployment.clear_cache()

    @classmethod
    def refresh_credentials(cls):
        credentials = fetch_credentials(
            prefix=btp_llm.PREFIX,
            home=cls.get_home(),
            cred_values=CREDENTIAL_VALUES,
            vcap_service_name='azure-openai-service-demo',
        )
        for name, value in credentials.items():
            setattr(btp_llm, name, value)
        cls._registries = {}

    @classmethod
    def get_home(cls):
        return pathlib.Path(os.environ.get(f'{btp_llm.PREFIX}_HOME', btp_llm.BTP_LLM_DEFAULT_HOME)).expanduser()
