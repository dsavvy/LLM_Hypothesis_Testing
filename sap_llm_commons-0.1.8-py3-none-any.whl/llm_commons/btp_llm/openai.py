import pathlib
from typing import Any

from .deprecation import warn_on_import

new_module = f'llm_commons.proxy.{pathlib.Path(__file__).stem}'

__all__ = ['BTPChatCompletion', 'BTPCompletion', 'BTPEmbedding']


def get_new_module(obj):
    return f'{new_module}.{obj.__name__}'


def __getattr__(name: str) -> Any:
    if name == 'BTPChatCompletion':
        from llm_commons.proxy.openai import ChatCompletion as client
        warn_on_import(name, get_new_module(client))
        return client
    elif name == 'BTPCompletion':
        from llm_commons.proxy.openai import Completion as client
        warn_on_import(name, get_new_module(client))
        return client
    elif name == 'BTPEmbedding':
        from llm_commons.proxy.openai import Embedding as client
        warn_on_import(name, get_new_module(client))
        return client
    else:
        raise AttributeError(f'Could not find: {name}')
