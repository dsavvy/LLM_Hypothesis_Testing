from typing import Any

from llm_commons.btp_llm.deprecation import warn_on_import

__all__ = [
    'BTPAlephAlpha', 'BTPChatOpenAI', 'ChatBTPOpenAI', 'BTPOpenAI', 'BTPOpenAIEmbeddings', 'BTPCohere',
    'BTPBedrockEmbeddings', 'BTPBedrock', 'BTPBedrockChat', 'BTPGooglePalm', 'BTPGoogleEmbeddings',
    'BTPHuggingFaceTextGenInference', 'init_embedding_model', 'init_llm', 'get_model_class'
]

fallback_module = f'llm_commons.langchain.proxy'


def get_new_module(obj, module_=None):
    module_ = module_ or fallback_module
    return f'{module_}.{obj.__name__}'


def __getattr__(name: str) -> Any:
    if name == 'BTPAlephAlpha':
        from llm_commons.langchain.proxy.aleph_alpha import AlephAlpha as client
        warn_on_import(name, get_new_module(client))
        return client

    elif name in ['ChatBTPOpenAI', 'BTPChatOpenAI']:
        from llm_commons.langchain.proxy.openai import ChatOpenAI as client
        warn_on_import(name, get_new_module(client))
        return client
    elif name == 'BTPOpenAI':
        from llm_commons.langchain.proxy.openai import OpenAI as client
        warn_on_import(name, get_new_module(client))
        return client
    elif name == 'BTPOpenAIEmbeddings':
        from llm_commons.langchain.proxy.openai import OpenAIEmbeddings as client
        warn_on_import(name, get_new_module(client))
        return client

    elif name == 'BTPBedrockChat':
        from llm_commons.langchain.proxy.bedrock import BedrockChat as client
        warn_on_import(name, get_new_module(client))
        return client
    elif name == 'BTPBedrock':
        from llm_commons.langchain.proxy.bedrock import Bedrock as client
        warn_on_import(name, get_new_module(client))
        return client
    elif name == 'BTPBedrockEmbeddings':
        from llm_commons.langchain.proxy.bedrock import BedrockEmbeddings as client
        warn_on_import(name, get_new_module(client))
        return client

    elif name == 'BTPCohere':
        from llm_commons.langchain.proxy.cohere import Cohere as client
        warn_on_import(name, get_new_module(client))
        return client

    elif name == 'BTPGooglePalm':
        from llm_commons.langchain.proxy.google import GooglePalm as client
        warn_on_import(name, get_new_module(client))
        return client
    elif name == 'BTPGoogleEmbeddings':
        from llm_commons.langchain.proxy.google import GoogleEmbeddings as client
        warn_on_import(name, get_new_module(client))
        return client

    elif name == 'BTPHuggingFaceTextGenInference':
        from llm_commons.langchain.proxy.huggingface import HuggingFaceTextGenInference as client
        warn_on_import(name, get_new_module(client))
        return client

    elif name == 'init_llm':
        from llm_commons.langchain.proxy.init_models import init_llm as client
        warn_on_import(name, get_new_module(client))
        return client
    elif name == 'init_embedding_model':
        from llm_commons.langchain.proxy.init_models import init_embedding_model as client
        warn_on_import(name, get_new_module(client))
        return client
    elif name == 'get_model_class':
        from llm_commons.langchain.proxy.init_models import get_model_class as client
        warn_on_import(name, get_new_module(client))
        return client
    else:
        raise AttributeError(f'Could not find: {name}')
