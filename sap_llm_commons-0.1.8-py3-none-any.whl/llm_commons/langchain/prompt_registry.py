from warnings import warn

from llm_commons.prompt_registry import *

warn(
    'The `prompt_registry` module was moved form `llm_commons.langchain.prompt_registry` to `llm_commons.prompt_registry`',
    DeprecationWarning,
    stacklevel=2)
