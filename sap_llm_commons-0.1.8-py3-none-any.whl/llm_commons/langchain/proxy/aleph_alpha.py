from typing import Dict, Optional

from langchain.llms import AlephAlpha as AlephAlpha_
from langchain.pydantic_v1 import root_validator

from llm_commons.proxy.base import BaseDeployment, ProxyClient

from .base import BaseAuth
from .init_models import Catalog


class AlephAlpha(BaseAuth, AlephAlpha_):

    @root_validator()
    def validate_environment(cls, values: Dict) -> Dict:
        values['proxy_client'] = cls._get_proxy_client(values)
        try:
            from llm_commons.proxy.aleph_alpha import Client
            values['client'] = Client(deployment_id=values['deployment_id'],
                                      config_id=values['config_id'],
                                      config_name=values['config_name'],
                                      model_name=values['proxy_model_name'],
                                      proxy_client=values['proxy_client'])
        except ImportError:
            raise ValueError('Could not import aleph_alpha_client python package. '
                             'Please it install it with `pip install aleph_alpha_client`.')
        return values


@Catalog.register(AlephAlpha, 'alephalpha')
def init_model(proxy_client: ProxyClient,
               deployment: BaseDeployment,
               temperature: float = 0.0,
               max_tokens: int = 256,
               top_k: Optional[int] = None,
               top_p: float = 1.):
    return AlephAlpha(deployment_id=deployment.deployment_id,
                      proxy_client=proxy_client,
                      temperature=temperature,
                      maximum_tokens=max_tokens,
                      top_k=top_k or 0,
                      top_p=top_p)
