from typing import Any, Dict, Optional

from langchain.llms import Cohere as Cohere_
from langchain.pydantic_v1 import root_validator

from llm_commons.proxy.base import BaseDeployment, ProxyClient

from .base import BaseAuth
from .init_models import Catalog


class Cohere(BaseAuth, Cohere_):

    @property
    def _default_params(self) -> Dict[str, Any]:
        default_params = super()._default_params
        return default_params

    @root_validator()
    def validate_environment(cls, values: Dict) -> Dict:
        values['proxy_client'] = cls._get_proxy_client(values)
        try:
            from llm_commons.proxy.cohere import Client
            values['client'] = Client(deployment_id=values['deployment_id'],
                                      config_id=values['config_id'],
                                      config_name=values['config_name'],
                                      model_name=values['proxy_model_name'],
                                      proxy_client=values['proxy_client'])
        except ImportError:
            raise ValueError('Could not import cohere python package. ')
        return values


@Catalog.register(Cohere, 'cohere-command')
def init_model(proxy_client: ProxyClient,
               deployment: BaseDeployment,
               temperature: float = 0.0,
               max_tokens: int = 256,
               top_k: Optional[int] = None,
               top_p: float = 1.):
    return Cohere(deployment_id=deployment.deployment_id,
                  proxy_client=proxy_client,
                  temperature=temperature,
                  max_tokens=max_tokens,
                  k=top_k or 0,
                  p=top_p)
