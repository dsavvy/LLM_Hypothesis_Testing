import os
from typing import Any, Dict, List, Mapping, Optional

import requests
from langchain.callbacks.manager import CallbackManagerForLLMRun
from langchain.embeddings.base import Embeddings
from langchain.llms.base import LLM
from langchain.llms.utils import enforce_stop_tokens
from langchain.pydantic_v1 import Extra, root_validator

from llm_commons.proxy.base import BaseDeployment, ProxyClient

from .base import BaseAuth
from .init_models import Catalog


class GooglePalm(BaseAuth, LLM):
    proxy_deployment: Any = None  #: :meta private:

    temperature: float = 0.2
    max_output_tokens: int = 256
    top_p: Optional[float] = 1.
    top_k: Optional[int] = None
    model_kwargs: Optional[Dict] = None

    class Config:
        """Configuration for this pydantic object."""

        extra = Extra.forbid

    @root_validator()
    def validate_environment(cls, values: Dict) -> Dict:
        values['proxy_client'] = cls._get_proxy_client(values)
        values['proxy_deployment'] = values['proxy_client'].get_deployment(
            deployment_id=values['deployment_id'],
            config_id=values['config_id'],
            config_name=values['config_name'],
            model_name=values['proxy_model_name'],
        )
        BaseAuth._set_deployment_parameters(values, values['proxy_deployment'])
        return values

    @property
    def model_name(self):
        return self.proxy_deployment.model_name

    @property
    def model_id(self):
        return self.proxy_deployment.model_name

    @property
    def _llm_type(self) -> str:
        """Return type of llm."""
        return 'google_palm'

    @property
    def model(self):
        return self.proxy_deployment.model_name

    @property
    def _identifying_params(self) -> Mapping[str, Any]:
        """Get the identifying parameters."""
        kwargs = {
            'temperature': self.temperature,
            'maxOutputTokens': self.max_output_tokens,
        }
        if self.top_p is not None:
            kwargs['topP'] = self.top_p
        if self.top_k is not None:
            kwargs['topK'] = self.top_k
        kwargs.update(self.model_kwargs or {})
        return kwargs

    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> str:
        input_body = {'instances': [{'content': prompt}]}
        input_body['parameters'] = {**self._identifying_params, **kwargs}
        try:
            response = requests.post(
                url=self.proxy_deployment.prediction_url,
                headers=self.proxy_client.request_header,
                json={
                    **input_body,
                    **self.proxy_deployment.additonal_request_body_kwargs()
                },
            )
            if response.status_code != 200:
                optional_detail = response.json().get('error')
                raise ValueError(f'Bedrock /complete call failed with status code {response.status_code}.'
                                 f' Details: {optional_detail}')
        except Exception as e:
            raise ValueError(f'Error raised by bedrock service: {e}')
        else:
            text = response.json()['predictions'][0]['content']

        if stop is not None:
            text = enforce_stop_tokens(text, stop)

        return text


@Catalog.register(GooglePalm, 'gcp-text-bison-001')
def init_google_palm_model(proxy_client: ProxyClient,
                           deployment: BaseDeployment,
                           temperature: float = 0.0,
                           max_tokens: int = 256,
                           top_k: Optional[int] = None,
                           top_p: float = 1.):
    return GooglePalm(deployment_id=deployment.deployment_id,
                      proxy_client=proxy_client,
                      temperature=temperature,
                      max_output_tokens=max_tokens,
                      top_k=top_k,
                      top_p=top_p)


class GoogleEmbeddings(BaseAuth, Embeddings):
    model_kwargs: Optional[Dict] = None
    proxy_deployment: Any = None  #: :meta private:

    class Config:
        """Configuration for this pydantic object."""

        extra = Extra.forbid

    @root_validator()
    def validate_environment(cls, values: Dict) -> Dict:
        values['proxy_client'] = cls._get_proxy_client(values)
        values['proxy_deployment'] = values['proxy_client'].get_deployment(
            deployment_id=values['deployment_id'],
            config_id=values['config_id'],
            config_name=values['config_name'],
            model_name=values['proxy_model_name'],
        )
        BaseAuth._set_deployment_parameters(values, values['proxy_deployment'])
        return values

    @property
    def model_name(self):
        return self.proxy_deployment.model_name

    @property
    def model_id(self):
        return self.proxy_deployment.model_name

    @property
    def model(self):
        return self.proxy_deployment.model_name

    def _embedding_func(self, *text: str) -> List[float]:
        """Call out to Google embedding endpoint."""
        # replace newlines, which can negatively affect performance.
        # text = text.replace(os.linesep, ' ')
        _model_kwargs = self.model_kwargs or {}
        try:
            json_ = {
                'instances': [{
                    'content': txt
                } for txt in text],
                **_model_kwargs,
                **self.proxy_deployment.additonal_request_body_kwargs()
            }
            response = requests.post(
                url=self.proxy_deployment.prediction_url,
                headers=self.proxy_client.request_header,
                json=json_,
            )
            if response.status_code != 200:
                optional_detail = response.json().get('error')
                raise ValueError(f'Google /embedding call failed with status code {response.status_code}.'
                                 f' Details: {optional_detail}')
            response_json = response.json()
            return [p['embeddings']['values'] for p in response_json['predictions']]
        except Exception as e:
            raise ValueError(f'Error raised by inference endpoint: {e}')

    def embed_documents(self, texts: List[str], chunk_size: int = 1) -> List[List[float]]:
        """Compute doc embeddings using a Bedrock model.

        Args:
            texts: The list of texts to embed.
            chunk_size: Bedrock currently only allows single string
                inputs, so chunk size is always 1. This input is here
                only for compatibility with the embeddings interface.


        Returns:
            List of embeddings, one for each text.
        """
        results = []
        for i in range(0, len(texts), chunk_size):
            response = self._embedding_func(*texts[i:i + chunk_size])
            results.extend(response)
        return results

    def embed_query(self, text: str) -> List[float]:
        """Compute query embeddings using a Bedrock model.

        Args:
            text: The text to embed.

        Returns:
            Embeddings for the text.
        """
        return self._embedding_func(text)[0]


@Catalog.register(GoogleEmbeddings, 'gcp-textembedding-gecko-001')
def init_embedding_model(proxy_client: ProxyClient, deployment: BaseDeployment):

    return GoogleEmbeddings(
        deployment_id=deployment.deployment_id,
        proxy_client=proxy_client,
    )
