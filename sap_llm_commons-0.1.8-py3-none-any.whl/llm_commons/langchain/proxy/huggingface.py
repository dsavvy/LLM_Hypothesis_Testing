from typing import Any, Dict, Optional

from langchain.llms import HuggingFaceTextGenInference as HuggingFaceTextGenInference_
from langchain.pydantic_v1 import root_validator

from llm_commons.proxy.base import BaseDeployment, ProxyClient

from .base import BaseAuth
from .init_models import Catalog


class HuggingFaceTextGenInference(BaseAuth, HuggingFaceTextGenInference_):
    do_sample: bool = True

    @property
    def _default_params(self) -> Dict[str, Any]:
        default_params = super()._default_params
        default_params['do_sample'] = self.do_sample
        return default_params

    @root_validator()
    def validate_environment(cls, values: Dict) -> Dict:
        """Validate that python package exists in environment."""
        values['proxy_client'] = cls._get_proxy_client(values)
        try:
            from llm_commons.proxy.huggingface import AsyncClient, Client
            values['client'] = Client(deployment_id=values['deployment_id'],
                                      config_id=values['config_id'],
                                      config_name=values['config_name'],
                                      model_name=values['proxy_model_name'],
                                      proxy_client=values['proxy_client'],
                                      timeout=values['timeout'])
            values['async_client'] = AsyncClient(deployment_id=values['deployment_id'],
                                                 config_id=values['config_id'],
                                                 config_name=values['config_name'],
                                                 model_name=values['proxy_model_name'],
                                                 proxy_client=values['proxy_client'],
                                                 timeout=values['timeout'])
        except ImportError:
            raise ImportError('Could not import text_generation python package. '
                              'Please install it with `pip install text_generation`.')
        return values


@Catalog.register(HuggingFaceTextGenInference, 'falcon-7b', 'falcon-40b-instruct',
                  'llama2-70b-chat-hf')  # , 'llama2-13b-chat-hf',
def init_model(proxy_client: ProxyClient,
               deployment: BaseDeployment,
               temperature: float = 0.0,
               max_tokens: int = 256,
               top_k: Optional[int] = None,
               top_p: float = 1.):
    do_sample = temperature > 0
    eps = 10e-3
    f_clip = lambda val: max(eps, min(val, 1 - eps))
    temperature = max(eps, temperature)
    top_p = f_clip(top_p)
    return HuggingFaceTextGenInference(do_sample=do_sample,
                                       deployment_id=deployment.deployment_id,
                                       proxy_client=proxy_client,
                                       temperature=temperature,
                                       max_new_tokens=max_tokens,
                                       top_k=top_k,
                                       top_p=top_p)
