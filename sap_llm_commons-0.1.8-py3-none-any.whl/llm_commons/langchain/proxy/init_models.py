from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from enum import Enum, auto
from typing import Callable, Dict, Optional, Union

from langchain.embeddings.base import Embeddings

from llm_commons.proxy.base import ProxyClient

try:
    from langchain.base_language import BaseLanguageModel
except ImportError:
    from langchain.schema import BaseLanguageModel

from llm_commons.proxy.base import ProxyClient, get_proxy_client, get_proxy_client_and_deployment, get_proxy_version


@dataclass
class RegisterDeployment:
    model: Union[BaseLanguageModel, Embeddings]
    init_func: Callable


class Catalog:

    class ModelType(Enum):
        LLM = auto()
        EMBEDDINGS = auto()

    models = {ModelType.EMBEDDINGS: {}, ModelType.LLM: {}}

    @classmethod
    def register(cls, base_class, *model_names):
        if issubclass(base_class, BaseLanguageModel):
            model_type = cls.ModelType.LLM
        elif issubclass(base_class, Embeddings):
            model_type = cls.ModelType.EMBEDDINGS
        else:
            raise TypeError('Tried to register unsupported class')

        def wrapper(func):
            for model_name in model_names:
                cls.models[model_type][model_name] = RegisterDeployment(model=base_class, init_func=func)
            return func

        return wrapper

    @staticmethod
    def _deployment_discovery_kwargs(model_name: Optional[str] = None,
                                     deployment_id: Optional[str] = None,
                                     config_id: Optional[str] = None,
                                     config_name: Optional[str] = None):
        if get_proxy_version().lower() == 'btp':
            return {'deployment_id': deployment_id or model_name}
        else:
            return {
                'model_name': model_name,
                'config_id': config_id,
                'config_name': config_name,
                'deployment_id': deployment_id,
            }

    @classmethod
    def init_llm(cls,
                 model_name: Optional[str] = None,
                 deployment_id: Optional[str] = None,
                 config_id: Optional[str] = None,
                 config_name: Optional[str] = None,
                 api_base: Optional[str] = None,
                 auth_url: Optional[str] = None,
                 resource_group: Optional[str] = None,
                 client_id: Optional[str] = None,
                 client_secret: Optional[str] = None,
                 proxy_client: Optional[ProxyClient] = None,
                 temperature: float = 0.0,
                 max_tokens: int = 256,
                 top_k: Optional[int] = None,
                 top_p: float = 1.) -> BaseLanguageModel:
        init_func = cls.get_registry_entry(model_name=model_name,
                                           deployment_id=deployment_id,
                                           model_type=cls.ModelType.LLM).init_func
        proxy_client, deployment = get_proxy_client_and_deployment(api_base=api_base,
                                                                   auth_url=auth_url,
                                                                   resource_group=resource_group,
                                                                   client_id=client_id,
                                                                   client_secret=client_secret,
                                                                   client=proxy_client,
                                                                   **cls._deployment_discovery_kwargs(
                                                                       model_name=model_name,
                                                                       config_id=config_id,
                                                                       config_name=config_name,
                                                                       deployment_id=deployment_id,
                                                                   ))
        return init_func(
            proxy_client=proxy_client,
            deployment=deployment,
            temperature=temperature,
            max_tokens=max_tokens,
            top_k=top_k,
            top_p=top_p,
        )

    @classmethod
    def init_embedding_model(cls,
                             model_name: Optional[str] = None,
                             deployment_id: Optional[str] = None,
                             config_id: Optional[str] = None,
                             config_name: Optional[str] = None,
                             api_base: Optional[str] = None,
                             auth_url: Optional[str] = None,
                             resource_group: Optional[str] = None,
                             client_id: Optional[str] = None,
                             client_secret: Optional[str] = None,
                             proxy_client: Optional[ProxyClient] = None) -> BaseLanguageModel:
        init_func = cls.get_registry_entry(model_name=model_name,
                                           deployment_id=deployment_id,
                                           model_type=cls.ModelType.EMBEDDINGS).init_func
        proxy_client, deployment = get_proxy_client_and_deployment(api_base=api_base,
                                                                   auth_url=auth_url,
                                                                   resource_group=resource_group,
                                                                   client_id=client_id,
                                                                   client_secret=client_secret,
                                                                   client=proxy_client,
                                                                   **cls._deployment_discovery_kwargs(
                                                                       model_name=model_name,
                                                                       config_id=config_id,
                                                                       config_name=config_name,
                                                                       deployment_id=deployment_id,
                                                                   ))
        return init_func(proxy_client=proxy_client, deployment=deployment)

    @classmethod
    def all_llms(cls) -> Dict[str, BaseLanguageModel]:
        return {name: deplyoment.model for name, deplyoment in cls.models[cls.ModelType.LLM].items()}

    @classmethod
    def all_embedding_models(cls) -> Dict[str, Embeddings]:
        return {name: deplyoment.model for name, deplyoment in cls.models[cls.ModelType.EMBEDDINGS].items()}

    @classmethod
    def get_registry_entry(cls,
                           model_name: Optional[str] = None,
                           deployment_id: Optional[str] = None,
                           api_base: Optional[str] = None,
                           auth_url: Optional[str] = None,
                           resource_group: Optional[str] = None,
                           client_id: Optional[str] = None,
                           client_secret: Optional[str] = None,
                           client: Optional[ProxyClient] = None,
                           only_available: bool = False,
                           model_type: Union[str, Catalog.ModelType] = None):
        model_name = model_name or deployment_id
        if only_available:
            client = client or get_proxy_client(api_base=api_base,
                                                auth_url=auth_url,
                                                resource_group=resource_group,
                                                client_id=client_id,
                                                client_secret=client_secret,
                                                client=client)
            avaliable_models = [d.name for d in client.get_deployments()]
            if len(avaliable_models) == 0:
                raise KeyError('No models available!')
        else:
            avaliable_models = None
        if avaliable_models and model_name not in avaliable_models:
            raise KeyError(f"Model '{model_name}' is not available!")

        if isinstance(model_type, str):
            model_type = cls.ModelType[model_type.upper()]
            model_type = [model_type]
        elif isinstance(model_type, cls.ModelType):
            pass
        elif model_type is None:
            model_type = [*cls.ModelType]

        if not isinstance(model_type, Sequence):
            model_type = [model_type]
        for type_ in model_type:
            try:
                return cls.models[type_][model_name]
            except KeyError:
                continue
        raise KeyError(f"Model '{model_name}' is not available!")


def init_llm(model_name: Optional[str] = None,
             deployment_id: Optional[str] = None,
             config_id: Optional[str] = None,
             config_name: Optional[str] = None,
             api_base: Optional[str] = None,
             auth_url: Optional[str] = None,
             resource_group: Optional[str] = None,
             client_id: Optional[str] = None,
             client_secret: Optional[str] = None,
             proxy_client: Optional[ProxyClient] = None,
             temperature: float = 0.0,
             max_tokens: int = 256,
             top_k: Optional[int] = None,
             top_p: float = 1.) -> BaseLanguageModel:
    return Catalog.init_llm(model_name=model_name,
                            deployment_id=deployment_id,
                            config_id=config_id,
                            config_name=config_name,
                            api_base=api_base,
                            auth_url=auth_url,
                            resource_group=resource_group,
                            client_id=client_id,
                            client_secret=client_secret,
                            proxy_client=proxy_client,
                            temperature=temperature,
                            max_tokens=max_tokens,
                            top_k=top_k,
                            top_p=top_p)


def init_embedding_model(
    model_name: Optional[str] = None,
    deployment_id: Optional[str] = None,
    config_id: Optional[str] = None,
    config_name: Optional[str] = None,
    api_base: Optional[str] = None,
    auth_url: Optional[str] = None,
    resource_group: Optional[str] = None,
    client_id: Optional[str] = None,
    client_secret: Optional[str] = None,
    proxy_client: Optional[ProxyClient] = None,
) -> Embeddings:
    return Catalog.init_embedding_model(
        model_name=model_name,
        deployment_id=deployment_id,
        config_id=config_id,
        config_name=config_name,
        api_base=api_base,
        auth_url=auth_url,
        resource_group=resource_group,
        client_id=client_id,
        client_secret=client_secret,
        proxy_client=proxy_client,
    )


def get_model_class(model_name: Optional[str] = None,
                    deployment_id: Optional[str] = None,
                    model_type: Union[str, Catalog.ModelType] = None) -> Union[BaseLanguageModel, Embeddings]:
    assert model_name or deployment_id
    return Catalog.get_registry_entry(model_name=model_name, deployment_id=deployment_id, model_type=model_type).model
