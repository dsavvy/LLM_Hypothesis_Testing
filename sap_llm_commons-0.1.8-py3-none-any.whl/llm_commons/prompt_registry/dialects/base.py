from __future__ import annotations

import abc
from collections.abc import Sequence
from enum import Enum
from typing import Optional, Union

from omegaconf import DictConfig, ListConfig


class Dialects:

    def __init__(self, default_dialect=None):
        self.default_dialect = default_dialect
        self._dialects = {}

    def register(self, arg=None):

        def wrapper(dialect_cls):
            if not issubclass(dialect_cls, Dialect):
                raise ValueError(f'Only subclasses of {Dialect.__module__}.Dialect can be registered')
            self._dialects[(name or isinstance.__name__).lower()] = dialect_cls()
            return dialect_cls

        if callable(arg):
            name = None
            # The decorator was used without parentheses
            return wrapper(arg)
        elif isinstance(arg, str):
            name = arg
            # The decorator was used with parentheses
            return wrapper
        else:
            raise ValueError('Unexpected error')

    def __getitem__(self, key):
        return self.get(key)

    def __setitem__(self, key, dialect):
        return Dialects.register(key)(dialect)

    def get(self, key: Optional[str] = None):
        key = key or self.default_dialect
        if key is None:
            raise ValueError('No dialect selected!')
        return self._dialects[key]


class ChatMsgType(Enum):
    AI = '🤖'
    Human = '🗣️'
    System = '📋'

    @classmethod
    def get_options(cls):
        return [members.name for members in cls.__members__.values()]


class Dialect(abc.ABC):

    @abc.abstractmethod
    def generate_chat_prompt(self, cfg_node: Union[str, ListConfig, Sequence]):
        ...

    @abc.abstractmethod
    def generate_prompt(self, cfg_node: Union[str, ListConfig, Sequence]):
        ...

    def __call__(self, cfg_node: Union[str, ListConfig, Sequence]):
        if _is_valid_text_prompt(cfg_node):
            return self.generate_prompt(cfg_node)
        elif _is_chat_prompt(cfg_node):
            return self.generate_chat_prompt(cfg_node)
        else:
            raise ValueError('Unknown formatting of the prompt!')


def _is_valid_text_prompt(prompt_definition):
    return isinstance(prompt_definition, str)


def _is_list_like(obj: Union[Sequence, ListConfig]):
    return isinstance(obj, (Sequence, ListConfig)) and not isinstance(obj, str)


def _is_chat_prompt(prompt_definition):
    if not _is_list_like(prompt_definition):
        return False
    msg_types = ChatMsgType.get_options()
    for msg in prompt_definition:
        if not isinstance(msg, (dict, DictConfig)) and len(msg) != 1:
            return False
        msg_type, msg_text = [*msg.items()][0]
        if msg_type not in msg_types or not isinstance(msg_text, str):
            return False
    return True


dialects = Dialects()
