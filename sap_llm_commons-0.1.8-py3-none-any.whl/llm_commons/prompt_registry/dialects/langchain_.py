from __future__ import annotations

from string import Formatter

from langchain.prompts import (
    AIMessagePromptTemplate,
    ChatPromptTemplate,
    HumanMessagePromptTemplate,
    PromptTemplate,
    SystemMessagePromptTemplate,
)
from langchain.prompts.chat import BaseMessagePromptTemplate
from langchain.schema import AIMessage, BaseMessage, HumanMessage, SystemMessage

from .base import ChatMsgType, Dialect, dialects


def _get_input_variables(text: str):
    return {v for _, v, _, _ in Formatter().parse(text) if v is not None}


DIALECT_NAME = 'langchain'


@dialects.register(DIALECT_NAME)
class LangchainDialect(Dialect):

    def generate_prompt(self, cfg_node):
        return PromptTemplate.from_template(cfg_node)

    def generate_chat_prompt(self, cfg_node):
        return ChatPromptTemplate.from_messages([self.create_chat_msg(msg) for msg in cfg_node])

    def create_chat_msg(self, msg):
        msg_cls = self.get_chat_msg_cls(msg)
        msg_text = [*msg.values()][0]
        if issubclass(msg_cls, BaseMessage):
            return msg_cls(content=msg_text)
        elif issubclass(msg_cls, BaseMessagePromptTemplate):
            return msg_cls.from_template(msg_text)

    def get_chat_msg_cls(self, msg):
        msg_type, msg_text = [*msg.items()][0]
        input_variables = _get_input_variables(msg_text)
        if len(input_variables) == 0:
            return {
                ChatMsgType.AI.name: AIMessage,
                ChatMsgType.Human.name: HumanMessage,
                ChatMsgType.System.name: SystemMessage
            }[msg_type]
        else:
            return {
                ChatMsgType.AI.name: AIMessagePromptTemplate,
                ChatMsgType.Human.name: HumanMessagePromptTemplate,
                ChatMsgType.System.name: SystemMessagePromptTemplate
            }[msg_type]


dialects.default_dialect = DIALECT_NAME
