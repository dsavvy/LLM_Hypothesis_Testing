import re

VALID_OPERATORS = set(['&', '|', '!', '(', ')'])


class Node:

    def evaluate(self, vars_set):
        pass


class AndNode(Node):

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, vars_set):
        return self.left.evaluate(vars_set) and self.right.evaluate(vars_set)


class OrNode(Node):

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, vars_set):
        return self.left.evaluate(vars_set) or self.right.evaluate(vars_set)


class NotNode(Node):

    def __init__(self, child):
        self.child = child

    def evaluate(self, vars_set):
        return not self.child.evaluate(vars_set)


class VarNode(Node):

    def __init__(self, name):
        self.name = name

    def evaluate(self, vars_set):
        return self.name in vars_set


def parse(tokens):
    stack = []
    postfix = []
    precedence = {'&': 2, '|': 1, '!': 3}

    for token in tokens:
        if token == '(':
            stack.append(token)
        elif token == ')':
            while stack and stack[-1] != '(':
                postfix.append(stack.pop())
            stack.pop()  # Pop '('
        elif token in ['&', '|', '!']:
            while stack and stack[-1] in precedence and precedence[token] < precedence[stack[-1]]:
                postfix.append(stack.pop())
            stack.append(token)
        else:
            postfix.append(token)

    while stack:
        postfix.append(stack.pop())

    stack = []
    for token in postfix:
        if token == '&':
            right = stack.pop()
            left = stack.pop()
            node = AndNode(left, right)
            stack.append(node)
        elif token == '|':
            right = stack.pop()
            left = stack.pop()
            node = OrNode(left, right)
            stack.append(node)
        elif token == '!':
            child = stack.pop()
            node = NotNode(child)
            stack.append(node)
        else:
            node = VarNode(token)
            stack.append(node)
    return stack[0]


def is_valid_variable_name(token):
    # A regex pattern that matches valid variable names based on your criteria
    pattern = r'^[a-z][a-z0-9-_]*$'
    return bool(re.match(pattern, token))


def check_valid_tokens(tokens):
    for token in tokens:
        if not (token in VALID_OPERATORS or is_valid_variable_name(token)):
            raise ValueError(f'Invalid character/token {token} in the expression.')


def has_balanced_parentheses(expression):
    stack = []
    for char in expression:
        if char == '(':
            stack.append(char)
        elif char == ')':
            if not stack:
                return False
            stack.pop()
    return not stack  # True if stack is empty, False otherwise


def slugify(s):
    # Convert the string to lowercase
    s = s.lower()

    # Replace any non-alphanumeric character with a hyphen
    s = re.sub(r'[^a-z0-9-_]+', '-', s)

    # Remove any trailing or leading hyphens
    s = s.strip('-')

    # Ensure that the slug doesn't contain multiple consecutive hyphens
    s = re.sub(r'-+', '-', s)

    # Raise an error if slug doesn't start with a lowercase letter
    if not s or not s[0].isalpha():
        raise ValueError(f"The resulting slug doesn't start with a lowercase letter! {s=}")

    return s


def evaluate_expression(expression, vars_set):
    vars_set = set([slugify(var) for var in vars_set])
    if not has_balanced_parentheses(expression):
        raise ValueError('Mismatched parentheses in the expression.')
    expression = expression.strip()
    if expression == '':
        raise ValueError('Empty Expression')
    tokens = re.findall(r'(\(|\)|\||&|!|[\w-]+|[^ \t\n\r\f\v\w&|!()]+)', expression)
    check_valid_tokens(tokens)
    ast = parse(tokens)
    return ast.evaluate(vars_set)
