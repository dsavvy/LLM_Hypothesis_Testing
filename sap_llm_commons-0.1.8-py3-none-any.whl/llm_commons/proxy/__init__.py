from __future__ import annotations

import os

from .base import get_proxy_client
from .identity import AICoreProxyClient

__all__ = ('get_proxy_client', )

proxy_version = None

# AI CORE PROXY SPECIFIC VALUES

PREFIX = 'AICORE_LLM'
AICORE_LLM_DEFAULT_HOME = f'{os.path.expanduser("~")}/.aicore_llm'

api_base = None
auth_url = None
client_id = None
client_secret = None
resource_group = None
