from typing import Any, Mapping, Optional
from warnings import warn

from aleph_alpha_client.aleph_alpha_client import (
    DEFAULT_REQUEST_TIMEOUT,
    AnyRequest,
    Client,
    CompletionRequest,
    CompletionResponse,
)

from llm_commons.btp_llm.identity import BTPProxyClient
from llm_commons.proxy.base import ProxyClient, get_proxy_client


class Client(Client):

    def __init__(self,
                 api_base: Optional[str] = None,
                 auth_url: Optional[str] = None,
                 resource_group: Optional[str] = None,
                 client_id: Optional[str] = None,
                 client_secret: Optional[str] = None,
                 proxy_client: Optional[ProxyClient] = None,
                 deployment_id: str = None,
                 config_name: str = None,
                 config_id: str = None,
                 model_name: str = None,
                 request_timeout_seconds: int = DEFAULT_REQUEST_TIMEOUT,
                 total_retries: int = 8,
                 nice: bool = False):
        self.client = proxy_client or get_proxy_client(
            api_base=api_base,
            auth_url=auth_url,
            client_id=client_id,
            client_secret=client_secret,
            resource_group=resource_group,
        )
        if deployment_id is None and isinstance(self.client, BTPProxyClient):
            deployment_id = 'alephalpha'
            warn("Please start setting an explicit value 'deployment_id' when using the BTP proxy.",
                 DeprecationWarning,
                 stacklevel=2)

        self.deployment = self.client.get_deployment(
            deployment_id=deployment_id,
            config_name=config_name,
            config_id=config_id,
            model_name=model_name,
        )
        self.host = self.deployment.prediction_url
        super().__init__(token='???',
                         host=self.host,
                         hosting=None,
                         request_timeout_seconds=request_timeout_seconds,
                         total_retries=total_retries,
                         nice=nice)

    @property
    def headers(self):
        return self.client.request_header

    def _build_json_body(self, request: AnyRequest, model: Optional[str]) -> Mapping[str, Any]:
        json_body = request.to_json()
        json_body.update(self.deployment.additonal_request_body_kwargs())
        return json_body

    def complete(self, request: CompletionRequest, **kwargs) -> CompletionResponse:
        self.session.headers = self.headers
        response = self._post_request('', request, model=self.deployment.model_name)
        return CompletionResponse.from_json(response)
