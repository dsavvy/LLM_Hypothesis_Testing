from __future__ import annotations

import json
import os
import threading
from abc import ABC, abstractmethod
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from llm_commons.proxy.vcap_services import VCAPEnvironment

THREAD_PROXY_VERSION_OVERWRITE = '_llm_proxy_version_overwrite'
PROXY_VERSION_ENV_VARIABLE = 'LLM_COMMONS_PROXY'

_thread_local = threading.local()

no_value = object()


@contextmanager
def proxy_version_context(proxy_version):
    if not isinstance(proxy_version, str):
        raise ValueError('proxy_version has to be a string')
    old_value = getattr(_thread_local, THREAD_PROXY_VERSION_OVERWRITE, no_value)
    setattr(_thread_local, THREAD_PROXY_VERSION_OVERWRITE, proxy_version.lower())
    try:
        yield
    finally:
        # Clear the flag when exiting the context
        if old_value is no_value:
            delattr(_thread_local, THREAD_PROXY_VERSION_OVERWRITE)
        else:
            setattr(_thread_local, THREAD_PROXY_VERSION_OVERWRITE, old_value)


def set_proxy_version(value):
    import llm_commons.proxy
    if not isinstance(value, str):
        raise ValueError('proxy_version has to be a string')
    llm_commons.proxy.proxy_version = value.lower()


def get_proxy_version(default=os.environ.get(PROXY_VERSION_ENV_VARIABLE, 'btp')):
    import llm_commons.proxy

    from ..btp_llm import BTPProxyClient as _  # make sure that both client types are registered

    thread_overwrite = getattr(_thread_local, '_llm_proxy_version_overwrite', None)
    return thread_overwrite or llm_commons.proxy.proxy_version or default


class ProxyClients:

    def __init__(self):
        self.clients = {}

    def register(
        self,
        name,
    ):

        def wrapper(proxy_cls):
            if not issubclass(proxy_cls, ProxyClient):
                raise ValueError('You can only register ProxyClient subclasses')
            self.clients[name] = proxy_cls
            return proxy_cls

        return wrapper

    def get_proxy_cls(self, proxy_version=None):
        proxy_version = proxy_version or get_proxy_version()
        return self.clients[proxy_version]


proxy_clients = ProxyClients()


class BaseDeployment(ABC):
    model_identification_kwargs = (
        'config_id',
        'config_name',
        'deployment_id',
        'model_name',
    )

    @abstractmethod
    def additonal_request_body_kwargs(self) -> Dict[str, Any]:
        ...

    @property
    def prediction_url_registry(self):
        return self.get_prediction_url_registry()

    @abstractmethod
    def get_prediction_url_registry(self):
        ...


class ProxyClient(ABC):
    deployment_class = BaseDeployment

    @property
    def request_header(self):
        return self.get_request_header()

    @property
    def deployments(self):
        return self.get_deployments()

    def get_deployment_url(self, **kwargs):
        return self.get_deployment(**kwargs).url

    def get_prediction_url(self, **kwargs):
        return self.get_deployment(**kwargs).prediction_url

    @abstractmethod
    def get_request_header(self):
        ...

    @abstractmethod
    def get_deployment(self, **kwargs):
        ...

    @abstractmethod
    def get_deployments(self, **kwargs):
        ...

    @abstractmethod
    def update_deployments(self, **kwargs):
        ...


class PredictionURLs:

    def __init__(self, suffixes: Dict[str, str]):
        self._suffixes = {}
        self.register(suffixes)

    def register(self, suffixes):
        cleaned_suffixes = {model_name: '/' + suffix.lstrip('/') for model_name, suffix in suffixes.items()}
        self._suffixes.update(cleaned_suffixes)

    def __call__(self, model_name, url, fixed_suffix=None):
        try:
            suffix = fixed_suffix or self._suffixes[model_name]
        except KeyError:
            raise KeyError(f'{model_name} is an not a known model. Models available are:\n'
                           + ', '.join([*self._suffixes.keys()]))
        if isinstance(url, str) and url.endswith(suffix):
            return url
        return url.rstrip('/?') + suffix


def get_proxy_client(api_base: Optional[str] = None,
                     auth_url: Optional[str] = None,
                     client_id: Optional[str] = None,
                     client_secret: Optional[str] = None,
                     resource_group: Optional[str] = None,
                     **kwargs):
    client_cls = proxy_clients.get_proxy_cls()
    return client_cls(api_base=api_base,
                      auth_url=auth_url,
                      client_id=client_id,
                      client_secret=client_secret,
                      resource_group=resource_group)


def get_proxy_client_and_deployment(api_base: Optional[str] = None,
                                    auth_url: Optional[str] = None,
                                    resource_group: Optional[str] = None,
                                    client_id: Optional[str] = None,
                                    client_secret: Optional[str] = None,
                                    client: Optional[ProxyClient] = None,
                                    deployment_id: str = None,
                                    config_name: str = None,
                                    config_id: str = None,
                                    model_name: str = None,
                                    **kwargs):
    client = client or get_proxy_client(
        api_base=api_base,
        auth_url=auth_url,
        client_id=client_id,
        client_secret=client_secret,
        resource_group=resource_group,
    )
    deployment = client.get_deployment(
        deployment_id=deployment_id,
        config_name=config_name,
        config_id=config_id,
        model_name=model_name,
    )
    return client, deployment


@dataclass
class CredentialsValue:
    name: str
    vcap_name: Optional[str] = None
    default: Optional[str] = None
    transform_fn: Optional[callable] = None


def init_config(prefix, home, profile: str = None):
    # Read configuration from ${PREFIX}_HOME/config_<profile>.json.
    home = Path(home)
    profile_value = profile or os.environ.get(f'{prefix}_PROFILE')
    path_to_config = home / (f'config_{profile_value}.json' if profile_value else 'config.json')
    config = {}
    if path_to_config.exists():
        try:
            with path_to_config.open(encoding='utf-8') as f:
                return json.load(f)
        except json.decoder.JSONDecodeError:
            raise ValueError(f'{path_to_config} is not a valid json file. Please fix or remove it!')
    elif profile:
        raise FileNotFoundError(f"Unable to locate {prefix}_PROFILE '{profile}' in '{home}')")
    return config


def from_conf(config, name, prefix, default=None, validate_fn=None):
    env_name = f'{prefix}_{name}'
    value = os.environ.get(env_name, config.get(env_name, default))
    if validate_fn and value is not None:
        validate_fn(env_name, value)
    return value


def fetch_credentials(prefix, home, cred_values: List[CredentialsValue], vcap_service_name: str = None):
    config = init_config(prefix=prefix, home=home)
    try:
        vcap_service = VCAPEnvironment.from_env()[vcap_service_name].flat_dict
    except ValueError:
        vcap_service = {}
    credentials = {}
    cred_value: CredentialsValue
    for cred_value in cred_values:
        default = vcap_service.get(cred_value.vcap_name, cred_value.default)
        value = from_conf(config, cred_value.name.upper(), default=default, prefix=prefix)
        if value is not None and cred_value.transform_fn:
            value = cred_value.transform_fn(value)
        credentials[cred_value.name] = value
    return credentials
