import json as jsonlib
from typing import Any, Optional
from warnings import warn

import cohere
import requests
from cohere.error import CohereAPIError, CohereConnectionError, CohereError
from requests.adapters import HTTPAdapter
from urllib3 import Retry

from llm_commons.btp_llm.identity import BTPProxyClient
from llm_commons.proxy.base import ProxyClient, get_proxy_client


class Client(cohere.Client):

    def __init__(
            self,
            api_key: str = None,  # -> will be force to be None
            num_workers: int = 64,
            request_dict: dict = {},
            check_api_key: bool = True,  # -> will be force to be False
            client_name: Optional[str] = None,  # -> will be force to be None
            max_retries: int = 3,
            timeout: int = 120,
            api_url: Optional[str] = None,
            api_base: Optional[str] = None,
            auth_url: Optional[str] = None,
            resource_group: Optional[str] = None,
            client_id: Optional[str] = None,
            client_secret: Optional[str] = None,
            proxy_client: Optional[ProxyClient] = None,
            deployment_id: str = None,
            config_name: str = None,
            config_id: str = None,
            model_name: str = None):
        self.client = proxy_client or get_proxy_client(
            api_base=api_base or api_url,
            auth_url=auth_url,
            client_id=client_id,
            client_secret=client_secret,
            resource_group=resource_group,
        )
        if deployment_id is None and isinstance(self.client, BTPProxyClient):
            deployment_id = 'cohere-command'
            warn("Please start setting an explicit value 'deployment_id' when using the BTP proxy.",
                 DeprecationWarning,
                 stacklevel=2)

        self.deployment = self.client.get_deployment(
            deployment_id=deployment_id,
            config_name=config_name,
            config_id=config_id,
            model_name=model_name,
        )
        super().__init__(api_key=None,
                         num_workers=num_workers,
                         request_dict=request_dict,
                         check_api_key=False,
                         client_name=None,
                         max_retries=max_retries,
                         timeout=timeout,
                         api_url=None)

    def _request(self, endpoint, json=None, files=None, method='POST', stream=False, params=None) -> Any:
        headers = self.client.request_header
        if json:
            headers['Content-Type'] = 'application/json'
        url = self.deployment.prediction_url
        if json:
            json.update(self.deployment.additonal_request_body_kwargs())
        with requests.Session() as session:
            retries = Retry(
                total=self.max_retries,
                backoff_factor=0.5,
                allowed_methods=['POST', 'GET'],
                status_forcelist=cohere.RETRY_STATUS_CODES,
                raise_on_status=False,
            )
            session.mount('https://', HTTPAdapter(max_retries=retries))
            session.mount('http://', HTTPAdapter(max_retries=retries))
            if stream:
                return session.request(method, url, headers=headers, json=json, **self.request_dict, stream=True)

            try:
                response = session.request(
                    method,
                    url,
                    headers=headers,
                    json=json,
                    files=files,
                    timeout=self.timeout,
                    params=params,
                    **self.request_dict,
                )
            except requests.exceptions.ConnectionError as e:
                raise CohereConnectionError(str(e)) from e
            except requests.exceptions.RequestException as e:
                raise CohereError(f'Unexpected exception ({e.__class__.__name__}): {e}') from e

            try:
                json_response = response.json()
            except jsonlib.decoder.JSONDecodeError:  # CohereAPIError will capture status
                raise CohereAPIError.from_response(response, message=f'Failed to decode json body: {response.text}')

            self._check_response(json_response, response.headers, response.status_code)
        return json_response
