from __future__ import annotations

import json
import os
import pathlib
import re
import time
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import datetime
from fnmatch import fnmatch
from functools import lru_cache, wraps
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from ai_api_client_sdk.models.status import Status
from ai_core_sdk.ai_core_v2_client import AICoreV2Client

import llm_commons.proxy as llm_proxy
from llm_commons.proxy.base import (
    BaseDeployment,
    CredentialsValue,
    PredictionURLs,
    ProxyClient,
    fetch_credentials,
    proxy_clients,
)

CACHE_TOKEN_TIMEOUT = 3600
CREDENTIAL_VALUES = [
    CredentialsValue(name='client_id', vcap_name='credentials.clientid'),
    CredentialsValue(name='client_secret', vcap_name='credentials.clientsecret'),
    CredentialsValue(name='auth_url',
                     vcap_name='credentials.url',
                     transform_fn=lambda url: url + ('' if url.endswith('/oauth/token') else '/oauth/token')),
    CredentialsValue(name='api_base',
                     vcap_name='credentials.serviceurls.AI_API_URL',
                     transform_fn=lambda url: url + ('' if url.endswith('/v2') else '/v2')),
    CredentialsValue(name='resource_group', default='default')
]


def _lru_cache_timeout(timeout=60):
    caching_times = []

    def wrapper(func):

        @lru_cache()
        def f_cached(_time, *args, **kwargs):
            return func(*args, **kwargs)

        @wraps(func)
        def f_wrapped(*args, _uncached=False, **kwargs):
            _time = time.time()
            if len(caching_times) == 0:
                caching_times.append(_time)
            elif (_time - caching_times[0]) > timeout or _uncached:
                caching_times[0] = _time
            return f_cached(caching_times[0], *args, **kwargs)

        return f_wrapped

    return wrapper


@dataclass(frozen=True)
class FoundationalModelScenario:
    scenario_id: str
    config_names: Optional[Union[List[str], str]] = None
    model_name_parameter: str = 'model_name'
    prediction_url_suffix: Optional[str] = None

    def __post_init__(self):
        if (self.config_names, str):
            self.__dict__['config_names'] = [self.config_names]
        elif self.config_names is None:
            self.__dict__['config_names'] = ['*']
        if self.prediction_url_suffix:
            self.__dict__['prediction_url_suffix'] = '/' + self.prediction_url_suffix.lstrip('/')


@proxy_clients.register('aicore')
class AICoreProxyClient(ProxyClient):
    foundational_model_scenarios = [
        FoundationalModelScenario(scenario_id='foundation-models', config_names='*', model_name_parameter='model_name'),
    ]
    _registries = {}
    _refresh: bool = True

    def __new__(cls,
                api_base: Optional[str] = None,
                auth_url: Optional[str] = None,
                client_id: Optional[str] = None,
                client_secret: Optional[str] = None,
                resource_group: Optional[str] = None):
        if cls._refresh:
            cls.refresh_credentials()
            cls._refresh = False
        key = (api_base, auth_url, client_id, client_secret, resource_group)
        if cls._registries.get(key) is None:
            cls._registries[key] = super(AICoreProxyClient, cls).__new__(cls)
        return cls._registries[key]

    def __init__(self,
                 api_base: Optional[str] = None,
                 auth_url: Optional[str] = None,
                 client_id: Optional[str] = None,
                 client_secret: Optional[str] = None,
                 resource_group: Optional[str] = None):
        if hasattr(self, 'api_base'):
            return  # skip init when alreay exists
        self.api_base = api_base
        self.auth_url = auth_url
        self.client_id = client_id
        self.client_secret = client_secret
        self.resource_group = resource_group

        self._deployments = None

    @classmethod
    def add_foundation_model_scenario(cls,
                                      scenario_id,
                                      config_names: Optional[List[str]] = None,
                                      prediction_url_suffix: Optional[str] = None,
                                      model_name_parameter: str = 'model_name'):
        cls.foundational_model_scenarios.append(
            FoundationalModelScenario(scenario_id=scenario_id,
                                      config_names=config_names,
                                      model_name_parameter=model_name_parameter,
                                      prediction_url_suffix=prediction_url_suffix))
        for client in cls._registries.values():
            client._deployments = None

    @property
    def ai_core_client(self):
        return get_aicore_client(api_base=self.api_base,
                                 auth_url=self.auth_url,
                                 client_id=self.client_id,
                                 client_secret=self.client_secret,
                                 resource_group=self.resource_group)

    def get_aicore_client_kwargs(self):
        return get_client_params(api_base=self.api_base,
                                 auth_url=self.auth_url,
                                 client_id=self.client_id,
                                 client_secret=self.client_secret,
                                 resource_group=self.resource_group)

    @_lru_cache_timeout(CACHE_TOKEN_TIMEOUT)
    def get_request_header(self):
        header = deepcopy(self.ai_core_client.rest_client.headers)
        header.update({'Authorization': self.get_new_token()})
        header.pop('AI-Client-Type')
        return header

    def get_new_token(self):
        return self.ai_core_client.rest_client.get_token()

    @lru_cache
    def get_deployment(self, raise_on_multiple: bool = False, **search_key_value):
        if len(search_key_value) == 0:
            raise ValueError('No key value pairs provided for model discovery')
        hits = []
        for deployment in self.deployments:
            match = False
            for key, value in search_key_value.items():
                if value is None:
                    continue
                deployment_value = getattr(deployment, key, None)
                if deployment_value is None:
                    continue
                elif deployment_value != value:
                    match = False
                    break
                elif deployment_value == value and not match:
                    match = True
            if match and not raise_on_multiple:
                return deployment
            elif match:
                hits.append(deployment)

        if len(hits) > 1 and raise_on_multiple:
            raise ValueError(
                "Multiple deployments match the query. Use 'raise_on_multiple=False' to return the latest deployment matching the query."
            )
        try:
            return hits[0]
        except IndexError:
            pass
        raise ValueError('No deployment found with: '
                         + ', '.join([f'deployment.{k} == {v}' for k, v in search_key_value.items()]))

    def get_deployments(self, **kwargs):
        if self._deployments is None:
            self.update_deployments()
        return self._deployments

    def update_deployments(self):
        self._deployments = []
        for scenario_info in self.foundational_model_scenarios:
            query = self.ai_core_client.deployment.query(status=Status.RUNNING, scenario_id=scenario_info.scenario_id)
            self.get_deployment.cache_clear()
            for deployment in query.resources:
                if any(fnmatch(deployment.configuration_name, n) for n in scenario_info.config_names):
                    self._deployments.append(
                        Deployment(url=deployment.deployment_url,
                                   deployment_id=deployment.id,
                                   created_at=deployment.created_at,
                                   config_id=deployment.configuration_id,
                                   config_name=deployment.configuration_name,
                                   custom_prediction_suffix=scenario_info.prediction_url_suffix,
                                   **config_parameters(scenario_info.model_name_parameter, self.ai_core_client,
                                                       deployment)))
        self._deployments = sorted(self._deployments, key=lambda d: d.created_at, reverse=True)
        return self._deployments

    @classmethod
    def refresh_credentials(cls):
        credentials = fetch_credentials(prefix=llm_proxy.PREFIX,
                                        home=cls.get_home(),
                                        vcap_service_name='aicore',
                                        cred_values=CREDENTIAL_VALUES)
        for name, value in credentials.items():
            setattr(llm_proxy, name, value)
        cls._registries = {}
        get_aicore_client.cache_clear()

    @classmethod
    def get_home(cls):
        return pathlib.Path(os.environ.get(f'{llm_proxy.PREFIX}_HOME', llm_proxy.AICORE_LLM_DEFAULT_HOME)).expanduser()


def is_within_aicore():
    # TODO: Add check to see whether the code is running within AI Core
    return False


def get_client_params(**kwargs):
    params = {}
    aliases = {'api_base': 'base_url'}
    for cred_value in CREDENTIAL_VALUES:
        param = cred_value.name
        keyword = aliases.get(param, param)
        params[keyword] = kwargs.get(param, None) or getattr(llm_proxy, param)
        env_variable = f'{llm_proxy.PREFIX}_{param.upper()}'
        if not params[keyword]:
            raise ValueError(
                f'Either explicitly provide a value for {param}, set llm_commons.proxy.{param} or use environment variable {env_variable}'
            )

    return params


@lru_cache
def get_aicore_client(api_base: Optional[str] = None,
                      auth_url: Optional[str] = None,
                      client_id: Optional[str] = None,
                      client_secret: Optional[str] = None,
                      resource_group: Optional[str] = None):
    if is_within_aicore():
        raise NotImplementedError
    else:
        params = get_client_params(api_base=api_base,
                                   auth_url=auth_url,
                                   client_id=client_id,
                                   client_secret=client_secret,
                                   resource_group=resource_group)
        return AICoreV2Client(**params)


OPEN_AI_CHAT_COMPLETION = '/chat/completions'
OPEN_AI_EMBEDDING = '/embeddings'
OPENSOURCE_COMPLETION = ''

prediction_urls = PredictionURLs({
    'gpt-35-turbo': OPEN_AI_CHAT_COMPLETION,
    'gpt-35-turbo-16k': OPEN_AI_CHAT_COMPLETION,
    'gpt-4': OPEN_AI_CHAT_COMPLETION,
    'gpt-4-32k': OPEN_AI_CHAT_COMPLETION,
    'text-embedding-ada-002': OPEN_AI_EMBEDDING,
    # 'tiiuae--falcon-40b-instruct': OPENSOURCE_COMPLETION, <- Seems to be not available yey
})


@dataclass(frozen=True)
class Deployment(BaseDeployment):
    url: str
    config_id: str
    config_name: str
    deployment_id: str
    model_name: str
    created_at: datetime
    additonal_parameters: Dict[str, str] = field(default_factory=dict)
    custom_prediction_suffix: Optional[str] = None

    def __getattr__(self, name):
        value = self.additonal_parameters.get(name, None)
        if value:
            return value
        raise AttributeError

    def get_prediction_url_registry(self):
        return prediction_urls

    @property
    def prediction_url(self):
        return self.prediction_url_registry(self.model_name, self.url, self.custom_prediction_suffix)

    def additonal_request_body_kwargs(self) -> Dict[str, Any]:
        return {}


def camel_to_snake(name):
    name = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
    return re.sub('([a-z0-9])([A-Z])', r'\1_\2', name).lower()


def config_parameters(model_name_parameter, ai_core_client, deployment):
    model_parameters = {}
    config = ai_core_client.configuration.get(deployment.configuration_id)
    model_parameters['executable_id'] = config.executable_id
    for param in config.parameter_bindings:
        model_parameters[camel_to_snake(param.key)] = param.value
    return {'model_name': model_parameters.pop(model_name_parameter, None), 'additonal_parameters': model_parameters}


def sanity_check_client_config(client: Optional[AICoreProxyClient] = None):
    from llm_commons.proxy.base import get_proxy_client, proxy_version_context
    with proxy_version_context('aicore'):
        client = client or get_proxy_client()
        assert isinstance(client, AICoreProxyClient), '...'
        kwargs = client.get_aicore_client_kwargs()
        assert kwargs['base_url'].endswith('/v2'), f"'base_url' should end with '/v2', got: {kwargs['base_url']}"
        assert kwargs['auth_url'].endswith(
            '/oauth/token'), f"'auth_url' should end with '/oauth/token', got: {kwargs['auth_url']}"
        try:
            _ = client.ai_core_client
        except Exception as err:
            raise RuntimeError('Failed to get AI Core client with following exception') from err
        deployments = client.update_deployments()
        assert len(deployments) > 0, 'All checks passed, but not deployment found'
        return deployments
