from openai import util
from openai.api_resources.abstract.engine_api_resource import EngineAPIResource
from openai.openai_response import OpenAIResponse

MAX_TIMEOUT = 20


class ProxyEngineAPIResource(EngineAPIResource):
    OBJECT_NAME = 'chat.completions'

    @classmethod
    def create(
        cls,
        api_key=None,
        api_base=None,
        api_type=None,
        request_id=None,
        api_version=None,
        organization=None,
        **params,
    ):
        proxy_deployment = params.pop('_deployment', None)
        (
            deployment_id,
            engine,
            timeout,
            stream,
            headers,
            request_timeout,
            typed_api_type,
            requestor,
            url,
            params,
        ) = ProxyEngineAPIResource.prepare_create_request(api_key, api_base, api_type, api_version, organization,
                                                          **params)
        url = f'?api-version={requestor.api_version}'
        if proxy_deployment:
            params.update(proxy_deployment.additonal_request_body_kwargs())
        response, _, api_key = requestor.request(
            'post',
            url,
            params=params,
            headers=headers,
            stream=stream,
            request_id=request_id,
            request_timeout=request_timeout,
        )
        if stream:
            # must be an iterator
            assert not isinstance(response, OpenAIResponse)
            return (util.convert_to_openai_object(
                line,
                api_key,
                api_version,
                organization,
                engine=engine,
                plain_old_data=cls.plain_old_data,
            ) for line in response)
        else:
            obj = util.convert_to_openai_object(
                response,
                api_key,
                api_version,
                organization,
                engine=engine,
                plain_old_data=cls.plain_old_data,
            )

            if timeout is not None:
                obj.wait(timeout=timeout or None)

        return obj

    @classmethod
    def prepare_create_request(
        cls,
        api_key=None,
        api_base=None,
        api_type=None,
        api_version=None,
        organization=None,
        **params,
    ):
        # pylint: disable=too-many-function-args
        (deployment_id, engine, timeout, stream, headers, request_timeout, typed_api_type, requestor, url,
         params) = ProxyEngineAPIResource._EngineAPIResource__prepare_create_request(
             api_key, api_base, api_type, api_version, organization, **params)
        # Necessary for BTP Proxy
        # params['deployment_id'] = deployment_id
        return (deployment_id, engine, timeout, stream, headers, request_timeout, typed_api_type, requestor, url,
                params)

    @classmethod
    async def acreate(
        cls,
        api_key=None,
        api_base=None,
        api_type=None,
        request_id=None,
        api_version=None,
        organization=None,
        **params,
    ):
        proxy_deployment = params.pop('_deployment', None)
        (
            deployment_id,
            engine,
            timeout,
            stream,
            headers,
            request_timeout,
            typed_api_type,
            requestor,
            url,
            params,
        ) = ProxyEngineAPIResource.prepare_create_request(api_key, api_base, api_type, api_version, organization,
                                                          **params)
        url = f'?api-version={requestor.api_version}'
        if proxy_deployment:
            params.update(proxy_deployment.additonal_request_body_kwargs())
        response, _, api_key = await requestor.arequest(
            'post',
            url,
            params=params,
            headers=headers,
            stream=stream,
            request_id=request_id,
            request_timeout=request_timeout,
        )

        if stream:
            # must be an iterator
            assert not isinstance(response, OpenAIResponse)
            return (util.convert_to_openai_object(
                line,
                api_key,
                api_version,
                organization,
                engine=engine,
                plain_old_data=cls.plain_old_data,
            ) async for line in response)
        else:
            obj = util.convert_to_openai_object(
                response,
                api_key,
                api_version,
                organization,
                engine=engine,
                plain_old_data=cls.plain_old_data,
            )

            if timeout is not None:
                await obj.await_(timeout=timeout or None)

        return obj
