from typing import Optional

from llm_commons.proxy.base import BaseDeployment, ProxyClient, get_proxy_client

from .proxy_api_engine_resource import ProxyEngineAPIResource

DEFAULT_API_VERSION = '2023-09-01-preview'


class ChatCompletion(ProxyEngineAPIResource):
    engine_required = False
    OBJECT_NAME = 'chat.completions'

    @classmethod
    def create(cls,
               *args,
               api_base: Optional[str] = None,
               auth_url: Optional[str] = None,
               resource_group: Optional[str] = None,
               client_id: Optional[str] = None,
               client_secret: Optional[str] = None,
               proxy_client: Optional[ProxyClient] = None,
               **kwargs):
        """Create a chat completion.
        :param api_base: URL of the OpenAI Proxy service
        :param token: OpenAI Proxy token. Provide either token or auth_url, client_id and client_secret
        :param auth_url: Authentication URL of the service instance
        :param client_id: Client ID of the service instance
        :param client_secret: Client secret of the service instance
        :param refresh_token: If True, pulls a new token given auth_url, client_id and client_secret
        :param kwargs: Additional parameters to pass to the API
        :return: The completion response
        """
        return _create(cls,
                       *args,
                       api_base=api_base,
                       auth_url=auth_url,
                       resource_group=resource_group,
                       client_id=client_id,
                       client_secret=client_secret,
                       proxy_client=proxy_client,
                       **kwargs)

    @classmethod
    async def acreate(cls,
                      *args,
                      api_base: Optional[str] = None,
                      auth_url: Optional[str] = None,
                      resource_group: Optional[str] = None,
                      client_id: Optional[str] = None,
                      client_secret: Optional[str] = None,
                      proxy_client: Optional[ProxyClient] = None,
                      **kwargs):
        return await _acreate(cls,
                              *args,
                              api_base=api_base,
                              auth_url=auth_url,
                              resource_group=resource_group,
                              client_id=client_id,
                              client_secret=client_secret,
                              proxy_client=proxy_client,
                              **kwargs)


class Completion(ProxyEngineAPIResource):
    engine_required = False
    OBJECT_NAME = 'completions'

    @classmethod
    def create(cls,
               *args,
               api_base: Optional[str] = None,
               auth_url: Optional[str] = None,
               resource_group: Optional[str] = None,
               client_id: Optional[str] = None,
               client_secret: Optional[str] = None,
               proxy_client: Optional[ProxyClient] = None,
               **kwargs):
        """Create a completion.
        :param api_base: URL of the BTP OpenAI Proxy service
        :param token: BTP OpenAI Proxy token. Provide either token or auth_url, client_id and client_secret
        :param auth_url: Authentication URL of the service instance
        :param client_id: Client ID of the service instance
        :param client_secret: Client secret of the service instance
        :param refresh_token: If True, pulls a new token given auth_url, client_id and client_secret
        :param kwargs: Additional parameters to pass to the API
        :return: The completion response
        """
        return _create(cls,
                       *args,
                       api_base=api_base,
                       auth_url=auth_url,
                       resource_group=resource_group,
                       client_id=client_id,
                       client_secret=client_secret,
                       proxy_client=proxy_client,
                       **kwargs)

    @classmethod
    async def acreate(cls,
                      *args,
                      api_base: Optional[str] = None,
                      auth_url: Optional[str] = None,
                      resource_group: Optional[str] = None,
                      client_id: Optional[str] = None,
                      client_secret: Optional[str] = None,
                      proxy_client: Optional[ProxyClient] = None,
                      **kwargs):
        return await _acreate(cls,
                              *args,
                              api_base=api_base,
                              auth_url=auth_url,
                              resource_group=resource_group,
                              client_id=client_id,
                              client_secret=client_secret,
                              proxy_client=proxy_client,
                              **kwargs)


def _create_kwargs(api_base=None,
                   auth_url=None,
                   resource_group=None,
                   client_id=None,
                   client_secret=None,
                   proxy_client=None,
                   **kwargs):
    proxy_client = proxy_client or get_proxy_client(api_base=api_base,
                                                    auth_url=auth_url,
                                                    resource_group=resource_group,
                                                    client_id=client_id,
                                                    client_secret=client_secret)
    deployment_id = None
    for kw in ('model', 'engine', 'deployment', 'deployment_id'):
        deployment_id = kwargs.pop(kw, None) or deployment_id
    kwargs['deployment_id'] = deployment_id
    model_identification = {}
    for key in proxy_client.deployment_class.model_identification_kwargs:
        model_identification[key] = kwargs.pop(key, None)
    for key in BaseDeployment.model_identification_kwargs:
        kwargs.pop(key, None)
    deployment = proxy_client.get_deployment(**model_identification)
    kwargs['deployment_id'] = deployment.deployment_id
    if 'model' not in kwargs:
        kwargs['model'] = deployment.model_name
    kwargs['api_base'] = deployment.prediction_url
    kwargs['headers'] = proxy_client.request_header
    kwargs['headers'].update({'Content-Type': 'application/json'})
    if kwargs.get('api_key', None) is None:
        kwargs['api_key'] = '???'
    kwargs['api_version'] = kwargs.get('api_version', DEFAULT_API_VERSION) or DEFAULT_API_VERSION
    kwargs['_deployment'] = deployment
    return kwargs


def _create(cls,
            *args,
            api_base=None,
            auth_url=None,
            resource_group=None,
            client_id=None,
            client_secret=None,
            proxy_client=None,
            **kwargs):
    kwargs = _create_kwargs(api_base=api_base,
                            auth_url=auth_url,
                            resource_group=resource_group,
                            client_id=client_id,
                            client_secret=client_secret,
                            proxy_client=proxy_client,
                            **kwargs)
    return ProxyEngineAPIResource.create(*args, **kwargs)


async def _acreate(cls,
                   *args,
                   api_base=None,
                   auth_url=None,
                   resource_group=None,
                   client_id=None,
                   client_secret=None,
                   proxy_client=None,
                   **kwargs):
    kwargs = _create_kwargs(api_base=api_base,
                            auth_url=auth_url,
                            resource_group=resource_group,
                            client_id=client_id,
                            client_secret=client_secret,
                            proxy_client=proxy_client,
                            **kwargs)
    return await ProxyEngineAPIResource.acreate(*args, **kwargs)
