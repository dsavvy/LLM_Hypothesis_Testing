import base64
import time
from typing import Optional

from openai import util
from openai.datalib.numpy_helper import assert_has_numpy
from openai.datalib.numpy_helper import numpy as np
from openai.error import TryAgain

from llm_commons.proxy.base import ProxyClient

from .proxy_api_engine_resource import ProxyEngineAPIResource
from .proxy_completion import _acreate, _create


class Embedding(ProxyEngineAPIResource):
    engine_required = False
    OBJECT_NAME = 'embeddings'

    @classmethod
    def create(cls,
               *args,
               api_base: Optional[str] = None,
               auth_url: Optional[str] = None,
               resource_group: Optional[str] = None,
               client_id: Optional[str] = None,
               client_secret: Optional[str] = None,
               proxy_client: Optional[ProxyClient] = None,
               **kwargs):
        """
        Creates a new embedding for the provided input and parameters.
        See https://platform.openai.com/docs/api-reference/embeddings for a list
        of valid parameters.
        """
        start = time.time()
        timeout = kwargs.pop('timeout', None)
        user_provided_encoding_format = kwargs.get('encoding_format', None)
        # If encoding format was not explicitly specified, we opaquely use base64 for performance
        if not user_provided_encoding_format:
            kwargs['encoding_format'] = 'base64'
        while True:
            try:
                response = _create(cls,
                                   *args,
                                   api_base=api_base,
                                   auth_url=auth_url,
                                   resource_group=resource_group,
                                   client_id=client_id,
                                   client_secret=client_secret,
                                   proxy_client=proxy_client,
                                   **kwargs)

                # If a user specifies base64, we'll just return the encoded string.
                # This is only for the default case.
                if not user_provided_encoding_format:
                    for data in response.data:

                        # If an engine isn't using this optimization, don't do anything
                        if type(data['embedding']) == str:
                            assert_has_numpy()
                            data['embedding'] = np.frombuffer(base64.b64decode(data['embedding']),
                                                              dtype='float32').tolist()

                return response
            except TryAgain as e:
                if timeout is not None and time.time() > start + timeout:
                    raise

                util.log_info('Waiting for model to warm up', error=e)

    @classmethod
    async def acreate(cls,
                      *args,
                      api_base=None,
                      token=None,
                      auth_url=None,
                      client_id=None,
                      client_secret=None,
                      proxy_client: Optional[ProxyClient] = None,
                      **kwargs):
        """
        Creates a new embedding for the provided input and parameters.

        See https://platform.openai.com/docs/api-reference/embeddings for a list
        of valid parameters.
        """
        start = time.time()
        timeout = kwargs.pop('timeout', None)
        user_provided_encoding_format = kwargs.get('encoding_format', None)
        # If encoding format was not explicitly specified, we opaquely use base64 for performance
        if not user_provided_encoding_format:
            kwargs['encoding_format'] = 'base64'
        while True:
            try:
                response = await _acreate(cls,
                                          *args,
                                          api_base=api_base,
                                          token=token,
                                          auth_url=auth_url,
                                          client_id=client_id,
                                          client_secret=client_secret,
                                          proxy_client=proxy_client,
                                          **kwargs)

                # If a user specifies base64, we'll just return the encoded string.
                # This is only for the default case.
                if not user_provided_encoding_format:
                    for data in response.data:

                        # If an engine isn't using this optimization, don't do anything
                        if type(data['embedding']) == str:
                            data['embedding'] = np.frombuffer(base64.b64decode(data['embedding']),
                                                              dtype='float32').tolist()

                return response
            except TryAgain as e:
                if timeout is not None and time.time() > start + timeout:
                    raise
                util.log_info('Waiting for model to warm up', error=e)
