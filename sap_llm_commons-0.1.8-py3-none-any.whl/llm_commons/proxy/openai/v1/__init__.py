from typing import Any

from llm_commons.proxy.base import get_proxy_version

from .clients import OpenAI


class GlobalClient:

    def __init__(self) -> None:
        self._client = {}

    @property
    def client(self):
        proxy_version = get_proxy_version()
        client = self._client.get(proxy_version, None)
        if not client:
            self._client[proxy_version] = OpenAI()
        return self._client[proxy_version]


_global_client = GlobalClient()


def __getattr__(name: str) -> Any:
    if name in ('completions', 'chat', 'embeddings'):
        return getattr(_global_client.client, name)
    else:
        return locals().get(name)
