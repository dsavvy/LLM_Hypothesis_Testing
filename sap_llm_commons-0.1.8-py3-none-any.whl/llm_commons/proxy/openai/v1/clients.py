from __future__ import annotations

import contextvars
from contextlib import contextmanager
from typing import Optional

import httpx
from openai import AsyncOpenAI as AsyncOpenAI_
from openai import OpenAI as OpenAI_
from openai._streaming import Stream
from openai._types import NOT_GIVEN, Completion, NotGiven, Omit
from openai.resources.chat import AsyncChat as AsyncChat_
from openai.resources.chat import Chat as Chat_
from openai.resources.chat.completions import AsyncChatCompletions as AsyncChatCompletions_
from openai.resources.chat.completions import Completions as ChatCompletions_
from openai.resources.completions import AsyncCompletions as AsyncCompletions_
from openai.resources.completions import Completions as Completions_
from openai.resources.embeddings import AsyncEmbeddings as AsyncEmbeddings_
from openai.resources.embeddings import Embeddings as Embeddings_

from llm_commons.proxy.base import ProxyClient, get_proxy_client

DEFAULT_API_VERSION = '2023-05-15'

_current_deployment = contextvars.ContextVar('current_deployment')


@contextmanager
def set_deployment(value):
    token = _current_deployment.set(value)
    try:
        yield
    finally:
        _current_deployment.reset(token)


def get_current_deployment():
    return _current_deployment.get(None)


def _if_set(value, alternative=NOT_GIVEN):
    return value if not isinstance(value, NotGiven) and value is not None else alternative


def _kwargs_if_set(**kwargs):
    filtered_kwargs = {}
    for name in [*kwargs.keys()]:
        if _if_set(kwargs[name]):
            filtered_kwargs[name] = kwargs[name]
    return filtered_kwargs


class Embeddings(Embeddings_):

    def create(self,
               *,
               model: str | None | NotGiven = NOT_GIVEN,
               deployment_id: str | None | NotGiven = NOT_GIVEN,
               model_name: str | None | NotGiven = NOT_GIVEN,
               config_id: str | None | NotGiven = NOT_GIVEN,
               config_name: str | None | NotGiven = NOT_GIVEN,
               **kwargs) -> Completion | Stream[Completion]:
        proxy_client: ProxyClient = self._client.proxy_client
        model_name = _if_set(model_name, _if_set(model))
        model_identification = _kwargs_if_set(
            deployment_id=deployment_id,
            model_name=model_name,
            config_id=config_id,
            config_name=config_name,
        )
        deployment = proxy_client.get_deployment(**model_identification)
        model_name = deployment.model_name or '???'
        with set_deployment(deployment):
            return super().create(model=model_name, **kwargs)


class AsyncEmbeddings(AsyncEmbeddings_):

    async def create(self,
                     *,
                     model: str | None | NotGiven = NOT_GIVEN,
                     deployment_id: str | None | NotGiven = NOT_GIVEN,
                     model_name: str | None | NotGiven = NOT_GIVEN,
                     config_id: str | None | NotGiven = NOT_GIVEN,
                     config_name: str | None | NotGiven = NOT_GIVEN,
                     **kwargs) -> Completion | Stream[Completion]:
        proxy_client: ProxyClient = self._client.proxy_client
        model_name = _if_set(model_name, _if_set(model))
        model_identification = _kwargs_if_set(
            deployment_id=deployment_id,
            model_name=model_name,
            config_id=config_id,
            config_name=config_name,
        )
        deployment = proxy_client.get_deployment(**model_identification)
        model_name = deployment.model_name or '???'
        with set_deployment(deployment):
            return await super().create(model=model_name, **kwargs)


class Completions(Completions_):

    def create(self,
               *,
               model: str | None | NotGiven = NOT_GIVEN,
               deployment_id: str | None | NotGiven = NOT_GIVEN,
               model_name: str | None | NotGiven = NOT_GIVEN,
               config_id: str | None | NotGiven = NOT_GIVEN,
               config_name: str | None | NotGiven = NOT_GIVEN,
               **kwargs) -> Completion | Stream[Completion]:
        proxy_client: ProxyClient = self._client.proxy_client
        model_name = _if_set(model_name, _if_set(model))
        model_identification = _kwargs_if_set(
            deployment_id=deployment_id,
            model_name=model_name,
            config_id=config_id,
            config_name=config_name,
        )
        deployment = proxy_client.get_deployment(**model_identification)
        model_name = deployment.model_name or '???'
        with set_deployment(deployment):
            return super().create(model=model_name, **kwargs)


class AsyncCompletions(AsyncCompletions_):

    async def create(self,
                     *,
                     model: str | None | NotGiven = NOT_GIVEN,
                     deployment_id: str | None | NotGiven = NOT_GIVEN,
                     model_name: str | None | NotGiven = NOT_GIVEN,
                     config_id: str | None | NotGiven = NOT_GIVEN,
                     config_name: str | None | NotGiven = NOT_GIVEN,
                     **kwargs) -> Completion | Stream[Completion]:
        proxy_client: ProxyClient = self._client.proxy_client
        model_name = _if_set(model_name, _if_set(model))
        model_identification = _kwargs_if_set(
            deployment_id=deployment_id,
            model_name=model_name,
            config_id=config_id,
            config_name=config_name,
        )
        deployment = proxy_client.get_deployment(**model_identification)
        model_name = deployment.model_name or '???'
        with set_deployment(deployment):
            return await super().acreate(model=model_name, **kwargs)


class Chat(Chat_):

    def __init__(self, client: OpenAI) -> None:
        super().__init__(client)
        self.completions = ChatCompletions(client)


class ChatCompletions(ChatCompletions_):

    def create(self,
               *,
               model: str | None | NotGiven = NOT_GIVEN,
               deployment_id: str | None | NotGiven = NOT_GIVEN,
               model_name: str | None | NotGiven = NOT_GIVEN,
               config_id: str | None | NotGiven = NOT_GIVEN,
               config_name: str | None | NotGiven = NOT_GIVEN,
               **kwargs) -> Completion | Stream[Completion]:
        proxy_client: ProxyClient = self._client.proxy_client
        model_name = _if_set(model_name, _if_set(model))
        model_identification = _kwargs_if_set(
            deployment_id=deployment_id,
            model_name=model_name,
            config_id=config_id,
            config_name=config_name,
        )
        deployment = proxy_client.get_deployment(**model_identification)
        model_name = deployment.model_name or '???'
        with set_deployment(deployment):
            return super().create(model=model_name, **kwargs)


class AsyncChat(AsyncChat_):

    def __init__(self, client: OpenAI) -> None:
        super().__init__(client)
        self.completions = AsyncChatCompletions(client)


class AsyncChatCompletions(AsyncChatCompletions_):

    async def create(self,
                     *,
                     model: str | None | NotGiven = NOT_GIVEN,
                     deployment_id: str | None | NotGiven = NOT_GIVEN,
                     model_name: str | None | NotGiven = NOT_GIVEN,
                     config_id: str | None | NotGiven = NOT_GIVEN,
                     config_name: str | None | NotGiven = NOT_GIVEN,
                     **kwargs) -> Completion | Stream[Completion]:
        proxy_client: ProxyClient = self._client.proxy_client
        model_name = _if_set(model_name, _if_set(model))
        model_identification = _kwargs_if_set(
            deployment_id=deployment_id,
            model_name=model_name,
            config_id=config_id,
            config_name=config_name,
        )
        deployment = proxy_client.get_deployment(**model_identification)
        model_name = deployment.model_name or '???'
        with set_deployment(deployment):
            return await super().create(model=model_name, **kwargs)


class OpenAI(OpenAI_):

    def __init__(self,
                 *,
                 api_base: Optional[str] = None,
                 auth_url: Optional[str] = None,
                 resource_group: Optional[str] = None,
                 client_id: Optional[str] = None,
                 client_secret: Optional[str] = None,
                 proxy_client: Optional[ProxyClient] = None,
                 api_version: str = DEFAULT_API_VERSION,
                 **kwargs) -> None:
        self.proxy_client = proxy_client or get_proxy_client(
            api_base=api_base,
            auth_url=auth_url,
            client_id=client_id,
            client_secret=client_secret,
            resource_group=resource_group,
        )
        for kwarg in ('api_key', 'organization', 'base_url'):
            kwargs.pop(kwarg, None)
        default_query = {'api-version': api_version, **kwargs.pop('default_query', {})}
        super().__init__(api_key='???', base_url='???', organization='???', default_query=default_query, **kwargs)

        self.completions = Completions(self)
        self.chat = Chat(self)
        self.edits = None
        self.embeddings = Embeddings(self)
        self.files = None
        self.images = None
        self.audio = None
        self.moderations = None
        self.models = None
        self.fine_tuning = None
        self.fine_tunes = None
        self.beta = None

    @property
    def default_headers(self) -> dict[str, str | Omit]:
        headers = super().default_headers
        headers.update(self.proxy_client.get_request_header())
        return headers

    def _prepare_url(self, *args, **kwargs) -> httpx.URL:
        return httpx.URL(get_current_deployment().prediction_url)

    def request(self, cast_to, options, *args, **kwargs):
        options.json_data.update(get_current_deployment().additonal_request_body_kwargs())
        return super().request(cast_to, options, *args, **kwargs)


class AsyncOpenAI(AsyncOpenAI_):

    def __init__(self,
                 *,
                 api_base: Optional[str] = None,
                 auth_url: Optional[str] = None,
                 resource_group: Optional[str] = None,
                 client_id: Optional[str] = None,
                 client_secret: Optional[str] = None,
                 proxy_client: Optional[ProxyClient] = None,
                 api_version: str = DEFAULT_API_VERSION,
                 **kwargs) -> None:
        self.proxy_client = proxy_client or get_proxy_client(
            api_base=api_base,
            auth_url=auth_url,
            client_id=client_id,
            client_secret=client_secret,
            resource_group=resource_group,
        )
        for kwarg in ('api_key', 'organization', 'base_url'):
            kwargs.pop(kwarg, None)
        default_query = {'api-version': api_version, **kwargs.pop('default_query', {})}
        super().__init__(api_key='???', base_url='???', organization='???', default_query=default_query, **kwargs)

        self.completions = AsyncCompletions(self)
        self.chat = AsyncChat(self)
        self.edits = None
        self.embeddings = AsyncEmbeddings(self)
        self.files = None
        self.images = None
        self.audio = None
        self.moderations = None
        self.models = None
        self.fine_tuning = None
        self.fine_tunes = None
        self.beta = None

    @property
    def default_headers(self) -> dict[str, str | Omit]:
        headers = super().default_headers
        headers.update(self.proxy_client.get_request_header())
        return headers

    def _prepare_url(self, *args, **kwargs) -> httpx.URL:
        return httpx.URL(get_current_deployment().prediction_url)

    def request(self, cast_to, options, *args, **kwargs):
        options.json_data.update(get_current_deployment().additonal_request_body_kwargs())
        return super().request(cast_to, options, *args, **kwargs)
