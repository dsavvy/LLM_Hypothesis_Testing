import os
from warnings import warn

from packaging import version

try:
    import pkg_resources
    __version__ = pkg_resources.require('sap-llm-commons')[0].version
except:  # pylint: disable=bare-except
    __version__ = 'unknown'

from gen_ai_hub.proxy.core.proxy_clients import PROXY_VERSION_ENV_VARIABLE, get_proxy_version, proxy_clients

proxy_version_explcity_set = os.environ.get(PROXY_VERSION_ENV_VARIABLE, None) or proxy_clients.proxy_version is not None

if get_proxy_version() != 'btp' and not proxy_version_explcity_set:
    msg = "Starting from verison 1.0.0 the default proxy_version was set to 'gen-ai-hub'. "
    msg += "Use gen_ai_hub.proxy.core.proxy_clients.set_proxy_version('btp') to set the proxy_version to 'btp'."
    warn(msg, stacklevel=2)

try:
    import openai
    _openai_is_below_1_0_0 = False
except ImportError:
    _openai_is_below_1_0_0 = None
else:
    _openai_is_below_1_0_0 = version.parse(openai.__version__) < version.parse('1.0.0')

if _openai_is_below_1_0_0:
    from llm_commons._deprecation import deprecation_warning_once_no_warn_notebook
    deprecation_warning_once_no_warn_notebook('Support for openai<1 is deprecated and will be removed in the future. '
                                              'Please upgrade to version 1.0.0 or higher. See the migration guide at '
                                              'https://github.com/openai/openai-python/discussions/742')

from .btp_llm.client import BTPProxyClient
from .proxy.client import AICoreProxyClient

WARN_ABOUT_GEN_AI_HUB_IMPORT = False


def enable_warn_about_gen_ai_hub_import():
    global WARN_ABOUT_GEN_AI_HUB_IMPORT
    WARN_ABOUT_GEN_AI_HUB_IMPORT = True
