import sys
import warnings
from typing import Optional


class LLMCommonsDeprecationWarning(DeprecationWarning):
    """A class for issuing deprecation warnings for LangChain users."""


def surface_btp_llm_deprecation_warnings() -> None:
    """Unmute LangChain deprecation warnings."""
    warnings.filterwarnings(
        'default',
        category=LLMCommonsDeprecationWarning,
    )


def deprecation_warning_once(msg):
    if not getattr(deprecation_warning_once, 'log', None):
        deprecation_warning_once.log = set()
    if msg not in deprecation_warning_once.log:
        warnings.warn(msg, LLMCommonsDeprecationWarning, stacklevel=2)
        deprecation_warning_once.log.add(msg)


def deprecation_warning_once_no_warn_notebook(msg):
    if hasattr(sys, 'ps2'):
        # No warnings for interactive environments.
        # This is done to avoid polluting the output of interactive environments
        # where users rely on auto-complete and may trigger this warning
        # even if they are not using any deprecated modules
        return
    deprecation_warning_once(msg)
