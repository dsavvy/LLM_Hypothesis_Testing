from __future__ import annotations

import os
import pathlib
from functools import cached_property, lru_cache
from http.client import HTTPException
from typing import Any, ClassVar, Dict, Final, List, Optional, Tuple, Type
from warnings import warn

import requests
from ai_core_sdk.credentials import CredentialsValue, fetch_credentials
from gen_ai_hub.proxy.core.base import BaseDeployment, BaseProxyClient
from gen_ai_hub.proxy.core.proxy_clients import proxy_clients
from gen_ai_hub.proxy.core.utils import PredictionURLs, lru_cache_extended
from pydantic import BaseModel, Field

CACHE_TOKEN_TIMEOUT: Final[int] = 3600
CREDENTIAL_VALUES = [
    CredentialsValue(name='client_id', vcap_key='credentials.uaa.clientid'),
    CredentialsValue(name='client_secret', vcap_key='credentials.uaa.clientsecret'),
    CredentialsValue(name='auth_url', vcap_key='credentials.uaa.url'),
    CredentialsValue(name='api_base', vcap_key='credentials.url')
]
PREFIX: Final[str] = 'BTP_LLM'  # TODO: Adjust to new name
AICORE_LLM_DEFAULT_HOME: Final[str] = f'{os.path.expanduser("~")}/.btp_llm'  # TODO: Adjust to new name


class BTPDeployment(BaseDeployment):
    url: str
    deployment_id: str
    model_name_override: Optional[str] = Field(None, alias='model_name')

    # class variables
    prediction_url_registry: ClassVar[PredictionURLs] = PredictionURLs()

    # abstractmethod implementations
    def additional_request_body_kwargs(self) -> Dict[str, Any]:
        return {'deployment_id': self.deployment_id}

    @classmethod
    def get_model_identification_kwargs(cls) -> Tuple[str]:
        return ('deployment_id', )

    @property
    def prediction_url(self):
        return self.prediction_url_registry(self.model_name, self.url)

    @property
    def model_name(self):
        return self.model_name_override or self.deployment_id


COMPLETION_ENDPOINT = '/api/v1/completions'
EMBEDDINGS_ENDPOINT = '/api/v1/embeddings'

BTPDeployment.prediction_url_registry.register({
    'text-davinci-003': COMPLETION_ENDPOINT,
    'gpt-35-turbo': COMPLETION_ENDPOINT,
    'gpt-4-turbo': COMPLETION_ENDPOINT,
    'gpt-4': COMPLETION_ENDPOINT,
    'gpt-4-32k': COMPLETION_ENDPOINT,
    'gpt-35-turbo-16k': COMPLETION_ENDPOINT,
    'gpt-35-turbo-instruct': COMPLETION_ENDPOINT,
    'alephalpha': COMPLETION_ENDPOINT,
    'anthropic-claude-v1': COMPLETION_ENDPOINT,
    'anthropic-claude-v2': COMPLETION_ENDPOINT,
    'anthropic-claude-instant-v1': COMPLETION_ENDPOINT,
    'anthropic-claude-v1-100k': COMPLETION_ENDPOINT,
    'anthropic-claude-v2-100k': COMPLETION_ENDPOINT,
    'anthropic-direct': COMPLETION_ENDPOINT,
    'ai21-j2-grande-instruct': COMPLETION_ENDPOINT,
    'ai21-j2-jumbo-instruct': COMPLETION_ENDPOINT,
    'amazon-titan-tg1-large': COMPLETION_ENDPOINT,
    'gcp-text-bison-001': COMPLETION_ENDPOINT,
    'cohere-command': COMPLETION_ENDPOINT,
    'falcon-7b': COMPLETION_ENDPOINT,
    'falcon-40b-instruct': COMPLETION_ENDPOINT,
    'llama2-13b-chat-hf': COMPLETION_ENDPOINT,
    'llama2-70b-chat-hf': COMPLETION_ENDPOINT,
    'text-embedding-ada-002-v2': EMBEDDINGS_ENDPOINT,
    'amazon-titan-e1t-medium': EMBEDDINGS_ENDPOINT,
    'gcp-textembedding-gecko-001': EMBEDDINGS_ENDPOINT
})


@proxy_clients.register('btp')
class BTPProxyClient(BaseProxyClient):
    api_base: Optional[str] = None
    auth_url: Optional[str] = None
    client_id: Optional[str] = None
    client_secret: Optional[str] = None
    profile: Optional[str] = None

    # class attributes
    default_values: ClassVar[Dict[str, Any]] = {}

    # abstracmethod implementations
    @property
    def request_header(self) -> Dict[str, Any]:
        return self.get_request_header()

    @property
    def deployments(self) -> List[BTPDeployment]:
        return self.get_deployments()

    @property
    def deployment_class(self) -> Type[BTPDeployment]:
        return BTPDeployment

    def select_deployment(self, deployment_id, verify_deployment_id: bool = True, **kwargs):
        if verify_deployment_id:
            if deployment_id not in BTPDeployment.prediction_url_registry._suffixes.keys():
                raise ValueError(f'Unknown deployment_id={deployment_id}')
        return BTPDeployment(url=self.api_base_resolved, deployment_id=deployment_id)

    # public methods
    def get_request_header(self):
        header = {}
        header.update({'Authorization': 'Bearer ' + self.get_token()})
        return header

    def get_deployments(self):
        return [self.select_deployment(id_) for id_ in BTPDeployment.prediction_url_registry._suffixes.keys()]

    @classmethod
    def set_default_values(cls, **kwargs):
        cls.default_values.update(kwargs)

    @classmethod
    def get_home(cls):
        return pathlib.Path(os.environ.get(f'{PREFIX}_HOME', AICORE_LLM_DEFAULT_HOME)).expanduser()

    @property
    def api_base_resolved(self):
        if self.api_base is None:
            self.api_base = self.get_btp_proxy_params()['api_base']
        return self.api_base

    def get_btp_proxy_params(self):
        credentials = fetch_credentials(prefix=PREFIX,
                                        home=self.get_home(),
                                        cred_values=CREDENTIAL_VALUES,
                                        vcap_service_name='azure-openai-service-demo',
                                        profile=self.profile)
        params = {}
        for name, value in credentials.items():
            params[name] = getattr(self, name, value) or self.default_values.get(name, value)
            if not params[name]:
                env_variable = f'{PREFIX}_{name.upper()}'
                raise ValueError(
                    f"Either explicitly provide a value for {name} during init, use BTPProxyClient.set_default_values({name}='...') or use environment variable {env_variable}"
                )
        return params

    @lru_cache_extended(timeout=CACHE_TOKEN_TIMEOUT, first_arg_self=True)
    def get_token(self):
        params = self.get_btp_proxy_params()
        return get_token(auth_url=params['auth_url'],
                         client_id=params['client_id'],
                         client_secret=params['client_secret'])


def get_token(auth_url: str, client_id: str, client_secret: str):
    """Get a token from XSUAA.
    :param auth_url: URL of the XSUAA service
    :param client_id: Client ID of the service instance
    :param client_secret: Client secret of the service instance
    :return: Access token
    """
    if not auth_url:
        raise ValueError(
            'Either explicitly provide a value for auth_url, set llm_commons.btp_llm.auth_url or use environment variable BTP_LLM_AUTH_URL'
        )
    if not client_id:
        raise ValueError(
            'Either explicitly provide a value for client_id, set llm_commons.btp_llm.client_id or use environment variable BTP_LLM_CLIENT_ID'
        )
    if not client_secret:
        raise ValueError(
            'Either explicitly provide a value for client_secret, set llm_commons.btp_llm.client_secret or use environment variable BTP_LLM_CLIENT_SECRET'
        )
    response = requests.post(auth_url + '/oauth/token',
                             params={'grant_type': 'client_credentials'},
                             auth=(client_id, client_secret),
                             timeout=5)
    if response.status_code == 200:
        token_data = response.json()
        return token_data['access_token']
    raise HTTPException(f'status_code={response.status_code}, detail={response.text}')


try:
    import llm_commons.langchain.proxy as _
except ImportError:
    pass
