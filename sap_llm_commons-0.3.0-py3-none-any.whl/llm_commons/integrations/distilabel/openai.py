# Copyright 2023-present, Argilla, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

from distilabel.llms.base import AsyncLLM
from distilabel.llms.typing import GenerateOutput
from distilabel.mixins.runtime_parameters import RuntimeParameter
from distilabel.steps.tasks.typing import ChatType
from gen_ai_hub.proxy.core import get_proxy_client
from pydantic import Field, PrivateAttr, validate_call

if TYPE_CHECKING:
    from openai import AsyncOpenAI


CLASS_ARGS_TO_SELECTION_MAPPING = [
    ('model', 'model_name'),
    ('config_name', 'config_name'),
    ('config_id', 'config_id'),
    ('deployment_id', 'deployment_id'),
]


class OpenAILLM(AsyncLLM):
    model: str
    proxy_client: Optional[Any] = Field(default=None, exclude=True)
    deployment_id: Optional[str] = None
    config_name: Optional[str] = None
    config_id: Optional[str] = None
    max_retries: RuntimeParameter[int] = Field(
        default=6,
        description='The maximum number of times to retry the request to the API before'
        ' failing.',
    )
    timeout: RuntimeParameter[int] = Field(
        default=120,
        description='The maximum time in seconds to wait for a response from the API.',
    )
    _aclient: Optional['AsyncOpenAI'] = PrivateAttr(...)
    _deployment_kwargs: Optional['Dict'] = PrivateAttr(...)

    def load(self) -> None:
        """Loads the `AsyncOpenAI` client to benefit from async requests."""
        super().load()
        proxy_client = self.proxy_client or get_proxy_client()

        select_kwargs = {
            proxy_client.deployment_class.get_main_model_identification_kwargs(): self.model
        }
        deployment_args = proxy_client.deployment_class.get_model_identification_kwargs()
        for cls_name, select_name in CLASS_ARGS_TO_SELECTION_MAPPING:
            if select_name not in deployment_args:
                continue
            if select_name not in select_kwargs:
                select_kwargs[select_name] = getattr(self, cls_name)
        deployment = proxy_client.select_deployment(**select_kwargs)
        self._deployment_kwargs = {key: getattr(deployment, key) for key in deployment_args}
        try:
            from gen_ai_hub.proxy.native.openai import AsyncOpenAI
        except ImportError as ie:
            raise ImportError('OpenAI Python client is not installed. Please install it using'
                              ' `pip install openai`.') from ie

        self._aclient = AsyncOpenAI(
            max_retries=self.max_retries,  # type: ignore
            timeout=self.timeout,
            proxy_client=self.proxy_client,
        )

    @property
    def model_name(self) -> str:
        """Returns the model name used for the LLM."""
        return self.model

    @validate_call
    async def agenerate(  # type: ignore
        self,
        input: ChatType,
        num_generations: int = 1,
        max_new_tokens: int = 128,
        frequency_penalty: float = 0.0,
        presence_penalty: float = 0.0,
        temperature: float = 1.0,
        top_p: float = 1.0,
        stop: Optional[Union[str, List[str]]] = None,
    ) -> GenerateOutput:
        """Generates `num_generations` responses for the given input using the OpenAI async
        client.

        Args:
            input: a single input in chat format to generate responses for.
            num_generations: the number of generations to create per input. Defaults to
                `1`.
            max_new_tokens: the maximum number of new tokens that the model will generate.
                Defaults to `128`.
            frequency_penalty: the repetition penalty to use for the generation. Defaults
                to `0.0`.
            presence_penalty: the presence penalty to use for the generation. Defaults to
                `0.0`.
            temperature: the temperature to use for the generation. Defaults to `0.1`.
            top_p: the top-p value to use for the generation. Defaults to `1.0`.
            stop: a string or a list of strings to use as a stop sequence for the generation.
                Defaults to `None`.

        Returns:
            A list of lists of strings containing the generated responses for each input.
        """
        completion = await self._aclient.chat.completions.create(  # type: ignore
            **self._deployment_kwargs,
            messages=input,  # type: ignore
            max_tokens=max_new_tokens,
            n=num_generations,
            frequency_penalty=frequency_penalty,
            presence_penalty=presence_penalty,
            temperature=temperature,
            top_p=top_p,
            stop=stop,
            timeout=50,
        )
        generations = []
        for choice in completion.choices:
            if (content := choice.message.content) is None:
                self._logger.warning(  # type: ignore
                    f"Received no response using OpenAI client (model: '{self.model}')."
                    f' Finish reason was: {choice.finish_reason}')
            generations.append(content)
        return generations
