from typing import Any, Literal

import openai
from dsp.modules.azure_openai import AzureOpenAI
from dsp.modules.lm import LM
from gen_ai_hub.proxy.native.openai import OpenAI as OpenAI_
from gen_ai_hub.proxy.native.openai.clients import DEFAULT_API_VERSION

try:
    OPENAI_LEGACY = int(openai.version.__version__[0]) == 0
except Exception:
    OPENAI_LEGACY = True

KWARGS_TO_SELECTION_MAPPING = [
    ('model', 'model_name'),
    ('config_name', 'config_name'),
    ('config_id', 'config_id'),
    ('deployment_id', 'deployment_id'),
]

class OpenAI(AzureOpenAI):

    def __init__(
        self,
        api_version: str | None = None,
        proxy_client: Any = None,
        system_prompt: str | None = None,
        model: str = 'gpt-35-turbo',
        model_type: Literal['chat', 'text'] = 'chat',
        **kwargs,
    ):

        self.system_prompt = system_prompt
        api_version = api_version or DEFAULT_API_VERSION
        if OPENAI_LEGACY:
            raise ValueError('OpenAI Legacy is not supported. Please install openai>=1.0.0!')
        LM.__init__(self, model)
        self.provider = 'openai'
        self.proxy_client = proxy_client
        self.client = OpenAI_(
            proxy_client=proxy_client,
            api_version=api_version,
        )
        self.api_version = api_version
        self.model_type = model_type
        proxy_client = self.client.proxy_client
        select_kwargs = {
            proxy_client.deployment_class.get_main_model_identification_kwargs(): model
        }
        deployment_args = proxy_client.deployment_class.get_model_identification_kwargs()
        for kwargs_name, select_name in KWARGS_TO_SELECTION_MAPPING:
            if select_name not in deployment_args:
                continue
            if select_name not in select_kwargs and kwargs_name in kwargs:
                select_kwargs[select_name] = kwargs.pop(kwargs_name)
        deployment = proxy_client.select_deployment(**select_kwargs)
        _deployment_kwargs = {key: getattr(deployment, key) for key in deployment_args}

        self.kwargs = {
            'model': model,
            'temperature': 0.0,
            'max_tokens': 150,
            'top_p': 1,
            'frequency_penalty': 0,
            'presence_penalty': 0,
            'n': 1,
            **kwargs,
            **_deployment_kwargs,
        }
        self.history: list[dict[str, Any]] = []

    def copy(self, **kwargs):
        """Returns a copy of the language model with the same parameters."""
        kwargs = {**self.kwargs, **kwargs}
        model = kwargs.pop('model')

        return self.__class__(
            model=model,
            api_version=self.api_version,
            proxy_client=self.proxy_client,
            model_type=self.model_type,
            **kwargs,
        )
