from typing import Any, Callable, Dict, Optional

from gen_ai_hub.proxy.core.utils import warn_once
from gen_ai_hub.proxy.native.openai import OpenAI
from haystack import component, default_from_dict, default_to_dict, logging
from haystack.components.generators.openai import OpenAIGenerator as OpenAIGeneratorHaystack
from haystack.dataclasses import StreamingChunk
from haystack.utils import deserialize_callable, serialize_callable

logger = logging.getLogger(__name__)

KWARGS_TO_SELECTION_MAPPING = [
    ('model', 'model_name'),
    ('config_name', 'config_name'),
    ('config_id', 'config_id'),
    ('deployment_id', 'deployment_id'),
]

@component
class OpenAIGenerator(OpenAIGeneratorHaystack):

    def __init__(
        self,
        model: str = 'gpt-35-turbo',
        streaming_callback: Optional[Callable[[StreamingChunk], None]] = None,
        system_prompt: Optional[str] = None,
        generation_kwargs: Optional[Dict[str, Any]] = None,
        proxy_client: Optional[Any] = None,
        deployment_id: Optional[str] = None,
        config_name: Optional[str] = None,
        config_id: Optional[str] = None,
        api_version: Optional[str] = None,
    ):
        self.model = model
        self.generation_kwargs = generation_kwargs or {}
        self.system_prompt = system_prompt
        self.streaming_callback = streaming_callback

        self.api_version = api_version

        self.custom_proxy_client = proxy_client is not None
        self.client = OpenAI(proxy_client=proxy_client, api_version=api_version)
        proxy_client = self.client.proxy_client
        potential_kwargs = {
            'deployment_id': deployment_id,
            'config_name': config_name,
            'config_id': config_id,
            'model': model
        }
        select_kwargs = {
            proxy_client.deployment_class.get_main_model_identification_kwargs(): potential_kwargs["model"]
        }
        deployment_args = proxy_client.deployment_class.get_model_identification_kwargs()
        for kwargs_name, select_name in KWARGS_TO_SELECTION_MAPPING:
            if select_name not in deployment_args:
                continue
            if select_name not in select_kwargs and kwargs_name in potential_kwargs:
                select_kwargs[select_name] = potential_kwargs.pop(kwargs_name)
        deployment = proxy_client.select_deployment(**select_kwargs)
        _deployment_kwargs = {key: getattr(deployment, key) for key in deployment_args}
        self.generation_kwargs.update(_deployment_kwargs)


    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'OpenAIGenerator':
        """
        Deserialize this component from a dictionary.

        :param data:
            The dictionary representation of this component.
        :returns:
            The deserialized component instance.
        """
        init_params = data.get('init_parameters', {})
        serialized_callback_handler = init_params.get('streaming_callback')
        if serialized_callback_handler:
            data['init_parameters']['streaming_callback'] = deserialize_callable(serialized_callback_handler)
        return default_from_dict(cls, data)

    def to_dict(self) -> Dict[str, Any]:
        """
        Serialize this component to a dictionary.

        :returns:
            The serialized component as a dictionary.
        """
        if self.custom_proxy_client:
            warn_once('Custom proxy client is not supported in serialization. '
                      'Skipping serialization of proxy client.')
        callback_name = serialize_callable(self.streaming_callback) if self.streaming_callback else None
        return default_to_dict(self,
                               model=self.model,
                               api_version=self.api_version,
                               streaming_callback=callback_name,
                               generation_kwargs=self.generation_kwargs,
                               system_prompt=self.system_prompt)
