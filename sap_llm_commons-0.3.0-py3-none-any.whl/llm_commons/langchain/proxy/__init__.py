from __future__ import annotations

from typing import Any

import llm_commons
from llm_commons._deprecation import deprecation_warning_once_no_warn_notebook

from .aleph_alpha import AlephAlpha
from .bedrock import Bedrock, BedrockChat, BedrockEmbeddings
from .cohere import Cohere
from .google import GoogleEmbeddings, GooglePalm
from .huggingface import HuggingFaceTextGenInference
from .init_models import get_model_class, init_embedding_model, init_llm
from .openai import ChatOpenAI, OpenAI, OpenAIEmbeddings

__all__ = [
    'AlephAlpha', 'OpenAI', 'OpenAIEmbeddings', 'HuggingFaceTextGenInference', 'BedrockEmbeddings', 'Bedrock',
    'BedrockChat', 'GooglePalm', 'GoogleEmbeddings', 'init_embedding_model', 'init_llm', 'get_model_class', 'Cohere',
    'ChatOpenAI'
]


def __getattr__(name: str):
    if name == 'init_llm' and llm_commons.WARN_ABOUT_GEN_AI_HUB_IMPORT:
        deprecation_warning_once_no_warn_notebook(
            "The module 'llm_commons.langchain.init_llm' is deprecated and will be removed in the future. "
            "Please use 'gen_ai_hub.proxy.langchain' instead.")
        return init_llm
    elif name == 'get_model_class' and llm_commons.WARN_ABOUT_GEN_AI_HUB_IMPORT:
        deprecation_warning_once_no_warn_notebook(
            "The module 'llm_commons.langchain.get_model_class' is deprecated and will be removed in the future. "
            "Please use 'gen_ai_hub.proxy.langchain' instead.")
        return get_model_class
    elif name == 'init_embedding_model' and llm_commons.WARN_ABOUT_GEN_AI_HUB_IMPORT:
        deprecation_warning_once_no_warn_notebook(
            "The module 'llm_commons.langchain.init_embedding_model' is deprecated and will be removed in the future. "
            "Please use 'gen_ai_hub.proxy.langchain' instead.")
        return init_embedding_model
    else:
        return locals().get(name)
