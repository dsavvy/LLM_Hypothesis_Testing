from gen_ai_hub.proxy.langchain.init_models import get_model_class, init_embedding_model, init_llm

import llm_commons
from llm_commons._deprecation import deprecation_warning_once_no_warn_notebook

__all__ = ('init_llm', 'init_embedding_model', 'get_model_class')


def __getattr__(name: str):
    if name == 'init_llm' and llm_commons.WARN_ABOUT_GEN_AI_HUB_IMPORT:
        deprecation_warning_once_no_warn_notebook(
            "The module 'llm_commons.langchain.proxy.init_models.init_llm' is deprecated and will be removed in the future. "
            "Please use 'gen_ai_hub.proxy.langchain' instead.")
        return init_llm
    elif name == 'get_model_class' and llm_commons.WARN_ABOUT_GEN_AI_HUB_IMPORT:
        deprecation_warning_once_no_warn_notebook(
            "The module 'llm_commons.langchain.proxy.init_models.get_model_class' is deprecated and will be removed in the future. "
            "Please use 'gen_ai_hub.proxy.langchain' instead.")
        return get_model_class
    elif name == 'init_embedding_model' and llm_commons.WARN_ABOUT_GEN_AI_HUB_IMPORT:
        deprecation_warning_once_no_warn_notebook(
            "The module 'llm_commons.langchain.proxy.init_models.init_embedding_model' is deprecated and will be removed in the future. "
            "Please use 'gen_ai_hub.proxy.langchain' instead.")
        return init_embedding_model
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
