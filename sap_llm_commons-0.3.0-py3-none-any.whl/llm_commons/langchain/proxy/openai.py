from __future__ import annotations

from typing import Optional

from gen_ai_hub.proxy.langchain.init_models import catalog
from packaging import version

from llm_commons import _openai_is_below_1_0_0

if _openai_is_below_1_0_0:
    from .openai_v0 import ChatOpenAI, OpenAI, OpenAIEmbeddings, init_chat_model, init_embedding_model
else:
    from .openai_v1 import ChatOpenAI, OpenAI, OpenAIEmbeddings, init_chat_model, init_embedding_model

__all__ = ('ChatOpenAI', 'OpenAI', 'OpenAIEmbeddings', 'init_chat_model', 'init_embedding_model')
