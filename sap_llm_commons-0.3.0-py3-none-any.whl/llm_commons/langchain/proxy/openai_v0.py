from typing import Any, Dict, List, Optional, Union

from gen_ai_hub.proxy.core.base import BaseDeployment, BaseProxyClient
from gen_ai_hub.proxy.langchain.base import BaseAuth
from gen_ai_hub.proxy.langchain.init_models import catalog
from langchain.pydantic_v1 import root_validator
from langchain_community.chat_models.openai import ChatOpenAI as ChatOpenAI_
from langchain_community.embeddings.openai import OpenAIEmbeddings as OpenAIEmbeddings_
from langchain_community.llms.openai import OpenAI as OpenAI_


class ChatOpenAI(BaseAuth, ChatOpenAI_):
    model_name: Optional[str] = None

    def __new__(cls, **data: Any):  # type: ignore
        """Initialize the OpenAI object."""
        data['model_name'] = data.get('model_name', '') or ''
        return super().__new__(cls)

    # pylint: disable=no-self-argument
    def __init__(self, *args, **kwargs):
        super().__init__(*args, openai_api_key='???', **kwargs)

    @root_validator()
    def validate_environment(cls, values: Dict) -> Dict:
        values['proxy_client'] = cls._get_proxy_client(values)
        from llm_commons.proxy.openai import ChatCompletion
        try:
            from llm_commons.proxy.openai import ChatCompletion
            values['client'] = ChatCompletion
        except ImportError:
            raise ValueError('Could not import openai python package. '
                             'Please it install it with `pip install openai`.')
        if values['n'] < 1:
            raise ValueError('n must be at least 1.')
        if values['n'] > 1 and values['streaming']:
            raise ValueError('n must be 1 when streaming.')

        deployment = values['proxy_client'].select_deployment(
            deployment_id=values.get('deployment_id', None),
            config_id=values.get('config_id', None),
            config_name=values.get('config_name', None),
            model_name=values.get('proxy_model_name', None),
        )
        BaseAuth._set_deployment_parameters(values, deployment)
        values['model_name'] = values.get('model_name', None) or values.get('model', None) or values.get(
            'proxy_model_name', None)
        return values

    @property
    def _default_params(self) -> Dict[str, Any]:
        params = super()._default_params
        if params.get('api_verison', '') == '':
            params['api_version'] = None
        kwargs = self.proxy_client.deployment_class.get_model_identification_kwargs()
        model_id_kwargs = {key: getattr(self, key) for key in kwargs}
        return {**params, 'proxy_client': self.proxy_client, **model_id_kwargs, 'model': ''}


class OpenAI(BaseAuth, OpenAI_):
    model_name: Optional[str] = None

    def __new__(cls, **data: Any):  # type: ignore
        """Initialize the OpenAI object."""
        data['model_name'] = data.get('model_name', '') or ''
        return super().__new__(cls)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, openai_api_key='???', **kwargs)

    # pylint: disable=no-self-argument
    @root_validator()
    def validate_environment(cls, values: Dict) -> Dict:
        values['proxy_client'] = cls._get_proxy_client(values)
        try:
            from llm_commons.proxy.openai import Completion
            values['client'] = Completion
        except ImportError:
            raise ValueError('Could not import openai python package. '
                             'Please it install it with `pip install openai`.')
        if values['n'] < 1:
            raise ValueError('n must be at least 1.')
        if values['n'] > 1 and values['streaming']:
            raise ValueError('n must be 1 when streaming.')
        deployment = values['proxy_client'].select_deployment(
            deployment_id=values.get('deployment_id', None),
            config_id=values.get('config_id', None),
            config_name=values.get('config_name', None),
            model_name=values.get('proxy_model_name', None),
        )
        BaseAuth._set_deployment_parameters(values, deployment)
        values['model_name'] = values.get('model_name', None) or values.get('model', None) or values.get(
            'proxy_model_name', None)
        return values

    @property
    def _default_params(self) -> Dict[str, Any]:
        params = super()._default_params
        if params.get('api_verison', '') == '':
            params['api_version'] = None
        kwargs = self.proxy_client.deployment_class.get_model_identification_kwargs()
        model_id_kwargs = {key: getattr(self, key) for key in kwargs}
        return {**params, 'proxy_client': self.proxy_client, **model_id_kwargs, 'model': ''}


class OpenAIEmbeddings(BaseAuth, OpenAIEmbeddings_):
    model: Optional[str] = None
    tiktoken_model_name: Optional[str] = 'text-embedding-ada-002'
    chunk_size: int = 16

    def __init__(self, *args, **kwargs):
        super().__init__(*args, openai_api_key='???', **kwargs)

    # pylint: disable=no-self-argument
    @root_validator()
    def validate_environment(cls, values: Dict) -> Dict:
        values['proxy_client'] = cls._get_proxy_client(values)
        try:
            from llm_commons.proxy.openai import Embedding
            values['client'] = Embedding
        except ImportError:
            raise ValueError('Could not import openai python package. '
                             'Please it install it with `pip install openai`.')
        deployment = values['proxy_client'].select_deployment(
            deployment_id=values.get('deployment_id', None),
            config_id=values.get('config_id', None),
            config_name=values.get('config_name', None),
            model_name=values.get('proxy_model_name', None),
        )
        BaseAuth._set_deployment_parameters(values, deployment)
        values['model'] = values.get('model', None) or values.get('model_name', None) or values.get(
            'proxy_model_name', None)
        values['model_name'] = values['model']
        return values

    @property
    def _invocation_params(self) -> Dict:
        params = super()._invocation_params
        if params.get('api_verison', '') == '':
            params['api_version'] = None
        kwargs = self.proxy_client.deployment_class.get_model_identification_kwargs()
        model_id_kwargs = {key: getattr(self, key) for key in kwargs}
        return {**params, 'proxy_client': self.proxy_client, **model_id_kwargs, 'model': ''}

    @property
    def _default_params(self) -> Dict[str, Any]:
        params = super()._default_params
        if params.get('api_verison', '') == '':
            params['api_version'] = None
        kwargs = self.proxy_client.deployment_class.get_model_identification_kwargs()
        model_id_kwargs = {key: getattr(self, key) for key in kwargs}
        return {**params, 'proxy_client': self.proxy_client, **model_id_kwargs, 'model': ''}


@catalog.register('btp', OpenAI, 'text-davinci-003', 'gpt-35-turbo-instruct')
def init_model(proxy_client: BaseProxyClient,
               deployment: BaseDeployment,
               temperature: float = 0.0,
               max_tokens: int = 256,
               top_k: Optional[int] = None,
               top_p: float = 1.):
    return OpenAI(deployment_id=deployment.deployment_id,
                  proxy_client=proxy_client,
                  temperature=temperature,
                  max_tokens=max_tokens,
                  top_p=top_p)


@catalog.register('aicore', ChatOpenAI, 'gpt-35-turbo', 'gpt-4', 'gpt-4-32k', 'gpt-35-turbo-16k')
@catalog.register('btp', ChatOpenAI, 'gpt-35-turbo', 'gpt-4', 'gpt-4-32k', 'gpt-35-turbo-16k', 'gpt-4-turbo')
def init_chat_model(proxy_client: BaseProxyClient,
                    deployment: BaseDeployment,
                    temperature: float = 0.0,
                    max_tokens: int = 256,
                    top_k: Optional[int] = None,
                    top_p: float = 1.):
    return ChatOpenAI(deployment_id=deployment.deployment_id,
                      proxy_client=proxy_client,
                      temperature=temperature,
                      max_tokens=max_tokens,
                      model_kwargs={'top_p': top_p})


@catalog.register('aicore', OpenAIEmbeddings, 'text-embedding-ada-002')
@catalog.register('btp', OpenAIEmbeddings, 'text-embedding-ada-002-v2')
def init_embedding_model(proxy_client: BaseProxyClient, deployment: BaseDeployment):
    return OpenAIEmbeddings(deployment_id=deployment.deployment_id, proxy_client=proxy_client, chunk_size=16)
