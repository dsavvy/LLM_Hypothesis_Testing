from __future__ import annotations

from typing import Optional

from gen_ai_hub.proxy.core.base import BaseDeployment, BaseProxyClient
from gen_ai_hub.proxy.langchain.init_models import catalog
from gen_ai_hub.proxy.langchain.openai import (
    ChatOpenAI,
    OpenAI,
    OpenAIEmbeddings,
    init_chat_model,
    init_embedding_model,
)

catalog.register('btp', ChatOpenAI, 'gpt-35-turbo', 'gpt-35-turbo-16k', 'gpt-4', 'gpt-4-32k',
                 'gpt-4-turbo')(init_chat_model)
catalog.register('aicore', ChatOpenAI, 'gpt-35-turbo', 'gpt-4', 'gpt-4-32k', 'gpt-35-turbo-16k', 'gpt-4-turbo',
                 'tiiuae--falcon-40b-instruct')(init_chat_model)

catalog.register('btp', OpenAIEmbeddings, 'text-embedding-ada-002-v2')(init_embedding_model)
catalog.register('aicore', OpenAIEmbeddings, 'text-embedding-ada-002')(init_embedding_model)


@catalog.register('btp', OpenAI, 'text-davinci-003', 'gpt-35-turbo-instruct')
def init_model(proxy_client: BaseProxyClient,
               deployment: BaseDeployment,
               temperature: float = 0.0,
               max_tokens: int = 256,
               top_k: Optional[int] = None,
               top_p: float = 1.):
    return OpenAI(deployment_id=deployment.deployment_id,
                  proxy_client=proxy_client,
                  temperature=temperature,
                  max_tokens=max_tokens,
                  top_p=top_p)
