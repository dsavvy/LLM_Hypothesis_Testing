from __future__ import annotations

import json
from contextlib import asynccontextmanager

import click
import httpx
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse

DEFAULT_API_VERSION = '2024-02-15-preview'
DEFAULT_TIMEOUT = 60


def build_app():
    from gen_ai_hub.proxy.core import get_proxy_client, get_proxy_version, set_proxy_version
    proxy_version = get_proxy_version()
    click.echo(f'Starting proxy for {proxy_version}')
    set_proxy_version(proxy_version)
    import llm_commons as _

    @asynccontextmanager
    async def setup_proxy_client(_):
        ctx['proxy_client'] = get_proxy_client()
        ctx['proxy_client'].get_deployments()
        yield
        ctx.clear()

    app = FastAPI(lifespan=setup_proxy_client)
    ctx = {}

    async def stream_response(url: str, json, headers: dict, params: dict = {}):
        async with httpx.AsyncClient() as client:
            async with client.stream('POST', url, headers=headers, json=json, params=params) as response:
                response.raise_for_status()
                async for chunk in response.aiter_bytes():
                    yield chunk

    @app.post('/{full_path:path}')
    async def proxy_request(full_path: str, request: Request):
        try:
            body = await request.body()
            params = {**request.query_params}
            if not 'api_version' in params:
                params['api-version'] = ctx.get('api_version', DEFAULT_API_VERSION)
            body = body.decode('utf-8')
            body = json.loads(body)

            stream = body.get('stream', False)
            model = body['model'].replace('.', '')
            deployment_cls = ctx['proxy_client'].deployment_class
            model_kwargs = {deployment_cls.get_main_model_identification_kwargs(): model}

            deployment = ctx['proxy_client'].select_deployment(**model_kwargs)
            body.update(deployment.additional_request_body_kwargs())
            extended_headers = {**request.headers}
            extended_headers.pop('authorization', None)
            extended_headers.pop('host', None)
            extended_headers.pop('content-length', None)
            extended_headers.update(ctx['proxy_client'].request_header)
            if deployment.prediction_url:
                url = deployment.prediction_url
            else:
                url = f"{deployment.url}/{full_path.removeprefix('v1/')}"
            if stream:
                return StreamingResponse(stream_response(url, headers=extended_headers, json=body, params=params))
            else:
                async with httpx.AsyncClient() as client:
                    response = await client.request('POST',
                                                    url,
                                                    headers=extended_headers,
                                                    json=body,
                                                    params=params,
                                                    timeout=ctx.get('timeout', DEFAULT_TIMEOUT))
                    if response.status_code == 200:
                        return JSONResponse(content=response.text, status_code=response.status_code)
                    else:
                        response.raise_for_status()
        except Exception as err:
            # Handle other exceptions (e.g., network issues or invalid URL) with a generic server error response
            return JSONResponse(content={'detail': f'Internal server error:\n{err}'}, status_code=500)

    return app, ctx, [setup_proxy_client]


@click.command()
@click.option('--host', default='localhost', help='Host address')
@click.option('--port', default=7999, help='Port number', type=int)
@click.option('--timeout', default=DEFAULT_TIMEOUT, help='Port number', type=int)
@click.option('--log-level',
              default='info',
              type=click.Choice(['debug', 'info', 'warning', 'error', 'critical'], case_sensitive=False),
              help='Logging level')
@click.option('--api-version', default=DEFAULT_API_VERSION, type=str, help='API version')
@click.option('--env-file', default=None, type=str, help='Custom env file')
def run_proxy(host, port, log_level, api_version, env_file, timeout):
    # Add warning that the server is experimental and only for local testing in red color
    click.secho('!!!!!!!!\nThis server is experimental and only for local testing!\n!!!!!!!!', fg='red', bold=True)
    import uvicorn
    from dotenv import load_dotenv
    load_dotenv(dotenv_path=env_file, override=True)
    app, ctx, _ = build_app()
    ctx['api_version'] = api_version
    ctx['timeout'] = timeout
    uvicorn.run(app, host=host, port=port, log_level=log_level)


if __name__ == '__main__':
    run_proxy()
