from __future__ import annotations

import importlib
import pathlib

from omegaconf import OmegaConf

from .registry import (
    PromptConfig,
    PromptRegistry,
    current_prompts,
    get_model_name_candidates,
    pass_prompts,
    prompt_from_config,
)

__all__ = [
    'PromptRegistry', 'current_prompts', 'prompt_from_config', 'pass_prompts', 'get_model_name_candidates',
    'PromptConfig'
]


def get_pkg_path(module_name, sub_path=None):
    module = importlib.import_module(module_name)
    module_path = pathlib.Path(module.__file__).parent
    module_path = module_path if sub_path is None else module_path / sub_path
    return str(module_path.resolve())


OmegaConf.register_new_resolver('pkg_path', get_pkg_path)
