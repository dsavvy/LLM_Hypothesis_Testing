from __future__ import annotations

from string import Formatter

from .base import ChatMsgType, Dialect, dialects


@dialects.register('openai')
class OpenAIDialect(Dialect):
    role_mapping = {ChatMsgType.AI.name: 'assistant', ChatMsgType.Human.name: 'user', ChatMsgType.System.name: 'system'}

    def generate_prompt(self, cfg_node):
        return cfg_node

    def generate_chat_prompt(self, cfg_node):
        messages = []
        for msg in cfg_node:
            role, txt = [*msg.items()][0]
            messages.append({'role': self.role_mapping[role], 'content': txt})
        return messages
