from __future__ import annotations

import inspect
import pathlib
from collections.abc import Iterable
from dataclasses import dataclass
from functools import wraps
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union
from warnings import warn

from omegaconf import DictConfig, ListConfig, OmegaConf
from typing_extensions import Unpack

from .dialects import Dialect, dialects
from .logics import evaluate_expression, slugify
from .tags import CHAT_MODEL_TAG, get_langchain_model_tags, tag_resolver

CONDITION_KEY = '.condition'

Config = Union[DictConfig, ListConfig, Dict]


@dataclass(frozen=True)
class ConfigKey:
    key: Union[str, List[str]]

    def __post_init__(self):
        key = self.key
        if isinstance(key, str):
            key = key.split('.')
        if not isinstance(key, list) or not all([isinstance(e, str) for e in key]):
            raise ValueError
        object.__setattr__(self, 'key', key)

    def __call__(self, cfg, value=None) -> Any:
        if value is not None:
            return value
        for k in self.key:
            cfg = cfg[k]
        return cfg

    def __add__(self, addition):
        self_type = type(self)
        if not isinstance(addition, self_type):
            addition = self_type(addition)
        return type(self)(self.key + addition.key)


def value_from_config(config, key):
    return ConfigKey(key=key)(config)


class PromptFromConfigKey(ConfigKey):

    def __call__(self, cfg, dialect=None, value=None) -> Any:
        dialect = dialect if isinstance(dialect, Dialect) else dialects.get(dialect)
        return dialect(super().__call__(cfg, value))


def prompt_from_config(config, key, dialect: Optional[str] = None):
    return PromptFromConfigKey(key=key)(cfg=config, dialect=dialect)


def current_prompts(llm=None, tags: Union[str, Callable] = None):
    return PromptRegistry.current_prompts(llm=llm, tags=tags)


def pass_prompts(func=None):
    wrapper = PromptRegistry._get_func_wrapper(*PromptRegistry.current_keys())
    if func is None:
        return wrapper
    return wrapper(func)


def _prepare_path(path: Union[str, pathlib.Path], verify: bool = True):
    if path is None:
        return None
    path = pathlib.Path(path).expanduser()
    if not path.exists():
        raise FileNotFoundError(path)
    return path


def is_class(obj):
    if callable(obj):
        if isinstance(obj, type):
            return True
        else:
            return False
    return obj


@dataclass
class PromptConfig:
    config: Union[str, pathlib.Path, Dict, OmegaConf]
    condition: Optional[str] = None

    def __post_init__(self):
        if isinstance(self.config, (str, pathlib.Path)):
            self.config = _prepare_path(self.config)

    def use(self, tags: Set[str]):
        if self.condition is None:
            return True
        return evaluate_expression(expression=self.condition, vars_set=tags)


RawConfig = Union[str, pathlib.Path, PromptConfig]


class PromptRegistry:
    """PromptRegistry to group prompt configs that can be attached to functions and classes.

    A PromptRegistry is initialized with a key that uniquely identifies it, i.e. for a given
    key the PromptRegistry is a singleton, so that can only be instantiated once.
    Once instantiated, new default and model specific configs can be registered with register_group.
    These are then attached to functions or classes with attach_group. E.g.

    ZERO_SHOT_REGISTRY = PromptRegistry('zero-shot')

    ZERO_SHOT_REGISTRY.register_group('evaluation', default='./path/to/default/prompt-config.yaml',
                                                    openai_gpt_4 = './path/to/model/specific/prompt-config-gpt4.yaml',
                                                    openai_gpt_35 = './path/to/model/specific/prompt-config-gpt35.yaml')

    @ZERO_SHOT_REGISTRY.attach_group('evaluation')
    def create_llm_predictor(llm: Union[BaseChatModel, BaseModel]):
        llm_specific_prompt_config_dict = current_prompts(llm)
        ...

    Registration and attaching can also be done in a single step with the group method, e.g.

    @ZERO_SHOT_REGISTRY.group('evaluation', default='./path/to/default/prompt-config.yaml',
                                           openai_gpt_4 = './path/to/model/specific/prompt-config-gpt4.yaml',
                                           openai_gpt_35 = './path/to/model/specific/prompt-config-gpt35.yaml')
    def create_llm_predictor(llm: Union[BaseChatModel, BaseModel]):
        llm_specific_prompt_config_dict = current_prompts(llm)
        ...

    current_prompts goes down the call-stack to search for any function or class that has been decorated with a group.
    If that is the case, it tries to find a matching config for the llm it was called with. If called with None, or it
    can't find a matching config, it will use only the default config. The matching is done by searching the config's key
    (openai_gpt_4, openai_gpt_35 in the example above) in the following set of model attributes: _llm_type, model_name,
    deployment, model. If a model specific config is found, it will be merged with the default config and override keys
    that are present in both.

    In order to override even model specific configs, you can use

    ZERO_SHOT_REGISTRY.override(overrides={'evaluation': './path/to/some/config/with/overides.yaml'})

    These will be merged after the model specific configs.
    """
    _registries = {}

    def __new__(cls, key):
        if cls._registries.get(key) is None:
            cls._registries[key] = super(PromptRegistry, cls).__new__(cls)
        return cls._registries[key]

    def __init__(self, key: str):
        """Initializes a PromptRegistry singleton.

        Args:
            key (str): Key to uniquely identify the PromptRegistry.
        """
        self.key = key
        if not hasattr(self, 'groups'):
            self.groups = {}
        if not hasattr(self, 'overrides'):
            self.overrides = {}

    @classmethod
    def current_keys(cls) -> Tuple[str, str]:
        """Retrieves the current registry and group and returns their keys.

        Searches the call stack for a class or function for with a group attached (registry_key, and group_key attributes)
        and returns their keys.

        Raises:
            ValueError: If no group of can be found in the call stack.

        Returns:
            Tuple[str, str]: Tuple of keys, e.g. (registry_key, group_key)
        """
        stack = inspect.stack()
        group_key = None
        registry_key = None
        for frame_info in stack:
            obj = None
            for key in ('self', 'cls'):
                obj = frame_info.frame.f_locals.get(key, None)
                if obj is not None:
                    break
            if frame_info.function != '_prompt_group_func_wrapped' and not obj:
                continue
            else:
                if frame_info.function == '_prompt_group_func_wrapped':
                    f_or_obj = frame_info.frame.f_locals.get('_prompt_group_func', None)
                elif obj:
                    f_or_obj = obj
                group_key = getattr(f_or_obj, '_group_key', None)
                registry_key = getattr(f_or_obj, '_registry_key', None)
            if group_key is not None and registry_key is not None:
                break
        if group_key is None or registry_key is None:
            raise ValueError('The stack does not include a function decorated with @PromptRegistry.group(...)')
        return registry_key, group_key

    @classmethod
    def current_prompt_selector(cls) -> PromptSelector:
        """Retrieves the current registry and group and returns groups PromptSelector.

        Searches the call stack for a class or function for with a group attached (registry_key, and group_key attributes)
        and returns the PromptSelector of that group.

        Returns:
            PromptSelector: PromptSelector of the current group.
        """
        registry_key, group_key = cls.current_keys()
        return cls._registries[registry_key].groups[group_key]

    @classmethod
    def current_prompts(cls, llm: Optional[Any] = None, tags: Union[str, Callable] = None) -> OmegaConf:
        """Retrieves the current registry and group and returns merged config for the given LLM.

        Searches the call stack for a class or function for with a group attached (registry_key, and group_key attributes).
        Then calls the groups PromptSelector with the llm and the overrides present in the registry, which then
        looks up and merges the corresponding configs.

        Args:
            llm (Union[BaseChatModel, BaseLLM]], optional): LLM for which the current config should be assembled. Defaults to None.

        Returns:
            OmegaConf: Merged configs for the given group, llm and overrides in the registry.
        """
        registry_key, group_key = cls.current_keys()
        registry = cls._registries[registry_key]
        prompt_selector = registry.groups[group_key]
        return prompt_selector(llm=llm, overrides=registry.overrides.get(group_key, None), tags=tags)

    def register_group(self,
                       key: str,
                       *configs: List[RawConfig],
                       default: RawConfig = None,
                       chat_model: RawConfig = None,
                       **model_specific: Unpack[RawConfig]) -> PromptSelector:
        """Registers and returns a PromptSelector

        Args:
            key (str): Key to identify the group of configs.
            default (str): Path to the default config.
            chat_model (str, optional): Path to the a config that is only active for chat_models. Defaults to None.
            **model_specific (str): kwargs for defining model specific configs, e.g. gpt4=./gpt4-config.yaml.

        Returns:
            PromptSelector: PromptSelector instance that was registered for the group key.
        """
        if default is not None:
            deprecation_warning_once(
                'Keyword arguments `default`, `chat_model`, and `**model_specific` are deprecated. Pass the yamls as arguments and set conditions for the yamls.'
            )
        self.groups[key] = PromptSelector(*configs, default=default, chat_model_override=chat_model, **model_specific)
        return self.groups[key]

    def group(self,
              key: str,
              *configs: List[RawConfig],
              default: RawConfig = None,
              chat_model: RawConfig = None,
              **model_specific: Unpack[RawConfig]):
        """Decorator to register and attach a group to a class or function.

        Args:
            key (str): Key to identify the group of configs.
            default (str): Path to the default config.
            chat_model (str, optional): Path to the a config that is only active for chat_models. Defaults to None.
            **model_specific (str): kwargs for defining model specific configs, e.g. gpt4=./gpt4-config.yaml.
        """
        self.register_group(key, *configs, default=default, chat_model=chat_model, **model_specific)
        return self.attach_group(key)

    def attach_group(self, key: str):
        """Decorator to attach a registered group to a class or function.

        Args:
            key (str): Key of under which the group to be attached is registered.

        Raises:
            ValueError: If no group is registered under the key.
        """
        if key not in self.groups:
            raise ValueError
        return self._get_func_wrapper(self.key, key)

    @staticmethod
    def _get_func_wrapper(registry_key, group_key):

        def wrapper(_prompt_group_func):
            if is_class(_prompt_group_func):
                setattr(_prompt_group_func, '_group_key', group_key)
                setattr(_prompt_group_func, '_registry_key', registry_key)
                return _prompt_group_func
            else:

                @wraps(_prompt_group_func)
                def _prompt_group_func_wrapped(*args, **kwargs):
                    _prompt_group_func._group_key = group_key
                    _prompt_group_func._registry_key = registry_key
                    return _prompt_group_func(*args, **kwargs)

                return _prompt_group_func_wrapped

        return wrapper

    def pass_prompts(self, func=None):
        """Function decorator to pass current group."""

        wrapper = self._get_func_wrapper(**self.current_keys())
        if func is None:
            return wrapper
        return wrapper(func)

    def override(self, overrides: Dict[str, Union[str, List[str]], Config]):
        """Adds overrides to registered groups.

        Args:
            overrides (Dict[str, Union[str, List[str]]]): Dictionary to map from group keys to paths/configs or list of paths/configs
                to override configs for the given group.

        Raises:
            ValueError: If override values are not either a path of list of paths.
        """
        for group_name, override in overrides.items():
            if isinstance(override, (str, pathlib.Path, dict)):
                override = [override]
            if isinstance(override, list):
                override = [
                    _prepare_path(config) if isinstance(config, (str, pathlib.Path)) else config for config in override
                ]
            else:
                raise ValueError('Override values must either be a path (str, pathlib.Path) or a list thereof.')
            overrides[group_name] = override
        self.overrides.update(overrides)

    def get_prompts(self, group_key: str, llm: Optional[Any] = None, tags: Union[str, Callable] = None):
        prompt_selector = self.groups[group_key]
        return prompt_selector(llm=llm, overrides=self.overrides.get(group_key, None), tags=tags)


def flatten(list_: List[Union[str, List]]) -> Set[str]:
    flat_list = set()
    for entry in list_:
        if isinstance(entry, str):
            flat_list.add(entry)
        elif isinstance(entry, Iterable):
            flat_list = flat_list | flatten(entry)
    return flat_list


class PromptSelector:
    """PromptSelector is a callable that assembles a config for a given model and overrides.

    Looks up and merged the default configs with the model specific config and overrides.
    """

    def __init__(self, *prompt_configs, default=None, chat_model_override=None, **model_specific):
        """Initializes a PromptSelector

        Args:
            default (str): Path to the default config.
            chat_model (str, optional): Path to the a config that is only active for chat_models. Defaults to None.
            **model_specific (str): kwargs for defining model specific configs, e.g. gpt4=./gpt4-config.yaml.
        """
        self.prompt_configs = []
        for cfg in prompt_configs:
            if isinstance(cfg, PromptConfig):
                pass
            elif isinstance(cfg, (str, pathlib.Path)):
                cfg = OmegaConf.load(cfg)
                cfg = PromptConfig(config=cfg, condition=cfg.pop(CONDITION_KEY, default=None))
            elif isinstance(cfg, (list, tuple)) and len(cfg) == 2 and isinstance(
                    cfg[0], (str, pathlib.Path, dict)) and isinstance(cfg[1], str):
                cfg = PromptConfig(config=cfg[0], condition=cfg[1])
            else:
                raise ValueError(cfg)
            self.prompt_configs.append(cfg)
        if chat_model_override:
            self.prompt_configs = [PromptConfig(chat_model_override, condition=CHAT_MODEL_TAG)] + self.prompt_configs
        if default is not None:
            self.prompt_configs = [PromptConfig(default)] + self.prompt_configs
        for model_tag, path in model_specific.items():
            model_name = slugify(model_tag)
            condition = f"{model_name} | {model_name.replace('_', '-')}"
            self.prompt_configs.append(PromptConfig(path, condition=condition))

    def select_prompt_configs(self, llm: Optional[Any] = None, tags: Union[str, Callable] = None) -> List[pathlib.Path]:
        """Returns the paths of the configs for the given model.

        Note, does not include the overrides, which are kept in the registry.

        Args:
            llm (Union[BaseChatModel, BaseLLM]], optional): LLM for which config path should be looked up.

        Returns:
            List[pathlib.Path]: List of paths to the default, and model specific configs found.
        """
        tags = tags or []
        if llm:
            tags += [llm]

        tags = flatten(tag_resolver(tags))
        return [cfg.config for cfg in self.prompt_configs if cfg.use(tags)]

    def __call__(self,
                 llm: Optional[Any] = None,
                 overrides: Optional[List[Union[pathlib.Path, str, Config]]] = None,
                 tags: Union[str, Callable] = None) -> OmegaConf:
        """Looks up and merges the default configs with the model specific config and overrides.

        Args:
            llm (Optional[Any], optional): LLM for which the configs should be assembled. Defaults to None.
            overrides (Optional[List[pathlib.Path, Config]], optional): List of paths or Configs to override configs. Defaults to None.

        Returns:
            OmegaConf: Merged config.
        """
        if llm is not None:
            deprecation_warning_once(
                'Keyword argument `llm` keyword argument is deprecated. Pass the llm in the list of tags instead!')
        overrides = [] if overrides is None else overrides
        configs = self.select_prompt_configs(llm, tags=tags) + overrides
        loaded_configs = []
        for config in configs:
            if isinstance(config, (str, pathlib.Path)):
                config = OmegaConf.load(config)
            elif isinstance(config, (DictConfig, dict)):
                pass
            loaded_configs.append(config)
        return OmegaConf.merge(*loaded_configs)


@wraps(get_langchain_model_tags)
def get_model_name_candidates(model) -> List[str]:
    return get_langchain_model_tags(model)


def deprecation_warning_once(msg):
    if not getattr(deprecation_warning_once, 'log', None):
        deprecation_warning_once.log = set()
    if msg not in deprecation_warning_once.log:
        warn(msg, DeprecationWarning, stacklevel=2)
        deprecation_warning_once.log.add(msg)
