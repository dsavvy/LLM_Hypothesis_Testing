from typing import Any, List, Optional, Sequence, Union

try:
    import langchain
    GOT_LANGCHAIN = True
except ImportError:
    GOT_LANGCHAIN = False
else:
    from langchain_core.language_models.chat_models import BaseChatModel
    from langchain_core.language_models.llms import BaseLLM

from .logics import slugify

DEFAULT_MODEL_KEYS = ('_llm_type', 'model_name', 'model', 'deployment', 'deployment_id')
CHAT_MODEL_TAG = 'chat-model'


class TagResolver:

    def __init__(self):
        self._resolver = []

    def register(self, *classes):

        def wrapper(func):
            self._resolver.append((classes, func))
            return func

        return wrapper

    def __call__(self, obj):
        for type_, func in self._resolver:
            if isinstance(obj, type_):
                return func(obj)
        if callable(obj):
            return obj()
        raise TypeError(type(obj))


tag_resolver = TagResolver()


@tag_resolver.register(str)
def pass_str(obj: str) -> str:
    return obj


@tag_resolver.register(tuple, list)
def pass_str(obj: Sequence[Any]) -> Sequence[Any]:
    return [tag_resolver(obj_i) for obj_i in obj]


if GOT_LANGCHAIN:

    @tag_resolver.register(BaseChatModel, BaseLLM)
    def get_langchain_model_tags(model: Union[BaseChatModel, BaseLLM], keys: Optional[List[str]] = None) -> List[str]:
        """Returns slugified versions of all model_key values of the given model.
        The returned values represent the keys which can be used reference models_specific configs for this model.
        Looks at the following attribute values: _llm_type, model_name, deployment, model of the given model.

        Args:
            model (Union[BaseChatModel, BaseLLM]]): LLM to check for it's model_keys.

        Returns:
            List[str]: List of slugified values of the models keys present in the given model.
        """
        tags = []
        if isinstance(model, BaseChatModel):
            tags.append(CHAT_MODEL_TAG)
        for key in (keys or DEFAULT_MODEL_KEYS):
            model_id = getattr(model, key, None)
            if model_id is not None:
                try:
                    tags.append(slugify(model_id))
                except ValueError:
                    pass
        return sorted(set(tags), key=tags.index)
else:

    def get_langchain_model_tags(*args, **kwargs):
        raise ImportError('`langchain` not installed')
