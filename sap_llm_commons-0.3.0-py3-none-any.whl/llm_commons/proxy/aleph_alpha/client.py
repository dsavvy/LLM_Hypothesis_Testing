from typing import Any, Mapping, Optional
from warnings import warn

from aleph_alpha_client.aleph_alpha_client import (
    DEFAULT_REQUEST_TIMEOUT,
    AnyRequest,
    Client,
    CompletionRequest,
    CompletionResponse,
)
from gen_ai_hub.proxy.core.proxy_clients import BaseProxyClient, get_proxy_client, set_proxy_version
from gen_ai_hub.proxy.core.utils import NOT_GIVEN, NotGiven, kwargs_if_set


class Client(Client):

    def __init__(self,
                 deployment_id: str | None | NotGiven = NOT_GIVEN,
                 model_name: str | None | NotGiven = NOT_GIVEN,
                 config_id: str | None | NotGiven = NOT_GIVEN,
                 config_name: str | None | NotGiven = NOT_GIVEN,
                 proxy_client: Optional[BaseProxyClient] = None,
                 request_timeout_seconds: int = DEFAULT_REQUEST_TIMEOUT,
                 total_retries: int = 8,
                 nice: bool = False):
        self.proxy_client = proxy_client or get_proxy_client()
        model_identification = kwargs_if_set(
            deployment_id=deployment_id,
            model_name=model_name,
            config_id=config_id,
            config_name=config_name,
        )
        self.deployment = self.proxy_client.select_deployment(**model_identification)
        self.host = self.deployment.prediction_url
        super().__init__(token='???',
                         host=self.host,
                         hosting=None,
                         request_timeout_seconds=request_timeout_seconds,
                         total_retries=total_retries,
                         nice=nice)

    @property
    def headers(self):
        return self.proxy_client.request_header

    def _build_json_body(self, request: AnyRequest, model: Optional[str]) -> Mapping[str, Any]:
        json_body = request.to_json()
        json_body.update(self.deployment.additional_request_body_kwargs())
        return json_body

    def complete(self, request: CompletionRequest, **kwargs) -> CompletionResponse:
        self.session.headers = self.headers
        response = self._post_request('', request, model=self.deployment.model_name)
        return CompletionResponse.from_json(response)
