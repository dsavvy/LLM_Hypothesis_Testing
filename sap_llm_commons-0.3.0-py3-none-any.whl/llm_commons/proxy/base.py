from gen_ai_hub.proxy.core.proxy_clients import (
    get_proxy_client,
    get_proxy_version,
    proxy_version_context,
    set_proxy_version,
)

import llm_commons
from llm_commons._deprecation import deprecation_warning_once_no_warn_notebook

if llm_commons.WARN_ABOUT_GEN_AI_HUB_IMPORT:
    deprecation_warning_once_no_warn_notebook(
        "The module 'llm_commons.proxy.base' is deprecated and will be removed in the future. "
        "Please use 'gen_ai_hub.proxy' instead.")
__all__ = ('get_proxy_version', 'set_proxy_version', 'proxy_version_context', 'get_proxy_client')
