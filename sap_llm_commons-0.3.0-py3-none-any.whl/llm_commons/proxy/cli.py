import json
import pathlib
from typing import Optional
from urllib.parse import urlparse

from gen_ai_hub.proxy.core.proxy_clients import proxy_clients

from .client import PREFIX as prefix


def create_config(prefix, **kwargs):
    return {f'{prefix}_{k}'.upper(): v for k, v in kwargs.items() if v is not None}


def is_valid_url(url: str, path_forbidden: bool = True) -> bool:
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc, not result.path if path_forbidden else True])
    except ValueError:
        return False


def create_cli():
    try:
        import click
    except ImportError:
        import sys
        print('To use the aicore-llm cli install click. Run `pip install click`')
        sys.exit(1)

    def prompt_url(text, max_tries=5, path_forbidden: bool = True):
        tries = 0
        url = None
        while url is None and tries != max_tries:
            url = click.prompt(text, type=str).rstrip('/')
            if not is_valid_url(url, path_forbidden):
                url = None
                msg = 'Input is not a valid url.'
                if path_forbidden:
                    msg += ' Enter url without any additional path or trailing slash.'
                click.echo(msg)
        if url is None:
            raise ValueError('Max tries reached!')
        return url

    @click.group()
    def cli():
        pass

    @cli.command()
    @click.option('-p', '--profile', 'profile', default='default', type=str)
    @click.option('-a', '--auth-url', 'auth_url', default=None, type=str)
    @click.option('-s', '--client-secret', 'client_secret', default=None, type=str)
    @click.option('-i', '--client-id', 'client_id', default=None, type=str)
    @click.option('-u', '--api-url', 'api_base', default=None, type=str)
    @click.option('-g', '--resource-group', 'resource_group', default='default', type=str)
    @click.option('-k',
                  '--service-key-json',
                  'service_key_json',
                  default=None,
                  type=click.Path(exists=True, file_okay=True, dir_okay=False))
    def configure(client_secret: Optional[str],
                  client_id: Optional[str],
                  api_base: Optional[str],
                  auth_url: Optional[str],
                  profile: Optional[str] = '',
                  resource_group: Optional[str] = 'default',
                  service_key_json: Optional[str] = None):
        proxy_version = 'aicore'

        client_cls = proxy_clients.get_proxy_cls(proxy_version)
        if service_key_json is not None:
            with pathlib.Path(service_key_json).open(encoding='utf-8') as stream:
                service_key = json.load(stream)
            api_base = service_key['serviceurls']['AI_API_URL']
            client_secret = service_key['clientsecret']
            client_id = service_key['clientid']
            auth_url = service_key['url']
        config_home = client_cls.get_home()
        if auth_url is None:
            auth_url = prompt_url('Please enter the authorization URL', path_forbidden=False)
        auth_url = auth_url.rstrip('/')
        if not auth_url.endswith('/oauth/token'):
            auth_url += '/oauth/token'
        # check if client_id is None and, if so, ask for user input
        if client_id is None:
            client_id = click.prompt('Please enter the client ID', type=str)
        # check if client_secret is None and, if so, ask for user input
        if client_secret is None:
            client_secret = click.prompt('Please enter the client secret', type=str)
        if api_base is None:
            api_base = prompt_url('Please enter the base API URL', path_forbidden=False)
        api_base = api_base.rstrip('/')
        if not api_base.endswith('/v2'):
            api_base += '/v2'
        resource_group = click.prompt('Please confirm or enter the AICore resource group', type=str, default='default')

        config_home.mkdir(parents=True, exist_ok=True)
        profile = None if profile is None or len(profile) == 0 or profile == 'default' else profile
        if profile is None:
            config_path = config_home / 'config.json'
        else:
            config_path = config_home / f'config_{profile.lower()}.json'
            click.echo(f'Remember to set `{prefix}_CONFIG={profile.lower()}` to use your profile.')

        config = create_config(prefix=prefix,
                               auth_url=auth_url,
                               client_id=client_id,
                               client_secret=client_secret,
                               api_base=api_base,
                               resource_group=resource_group)
        click.echo(f'Creating new config {config_path}')
        if config_path.exists():
            profile_str = 'the default profile' if profile is None else f"'{profile}'"
            if not click.confirm(f'A config file for {profile_str} already exists. To do want to replace it?'):
                exit()
        with config_path.open('w', encoding='utf-8') as stream:
            json.dump(config, stream, indent=4)

    try:
        import langchain
    except ImportError as err:
        pass
    else:
        from gen_ai_hub.proxy.langchain.init_models import catalog
        from langchain.chains import LLMChain
        from langchain_core.prompts import PromptTemplate

    @cli.command()
    @click.argument('request')
    @click.option('-m', '--model-name', 'model_name', default='gpt-35-turbo')
    @click.option('-t',
                  '--temperature',
                  'temperature',
                  default=0.,
                  type=float,
                  help='Temperature used for the LLM call')
    @click.option('-n', '--max-tokens', 'max_tokens', default=256, type=int, help='Number of max tokens')
    @click.option('-v', '--verbose', 'verbose', default=False, help='Verbose langchain output')
    def complete(model_name: str, request: str, temperature: float, max_tokens: int, verbose: bool):
        if err is not None:
            raise err from RuntimeError('Missing package')
        model_kwargs = {'model_name': model_name}
        llm = catalog.init_llm(temperature=temperature, max_tokens=max_tokens, **model_kwargs)
        prompt = PromptTemplate(template='{request}', input_variables=['request'])
        llm_chain = LLMChain(prompt=prompt, llm=llm, verbose=verbose)
        click.echo(llm_chain.predict(request=request))

    @cli.command()
    def check():
        from llm_commons.proxy.identity import sanity_check_client_config
        deployments = sanity_check_client_config()
        click.echo('Everything appears to be configured correctly!')
        click.echo(f'Found {len(deployments)} deployments:\n'
                   + '\n'.join([f'- id: {dep.deployment_id} [{dep.model_name}]' for dep in deployments]))

    return cli


cli = create_cli()

if __name__ == '__main__':
    cli()
