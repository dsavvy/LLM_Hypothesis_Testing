from __future__ import annotations

import os
import pathlib
from typing import Any
from ai_core_sdk.ai_core_v2_client import AICoreV2Client
try:
    from ai_core_sdk.credentials import CREDENTIAL_VALUES, CredentialsValue
except ImportError:
    from ai_core_sdk.ai_core_v2_client import CREDENTIAL_VALUES, CredentialsValue
from ai_core_sdk.credentials import fetch_credentials
from gen_ai_hub.proxy.core.proxy_clients import proxy_clients
from gen_ai_hub.proxy.gen_ai_hub_proxy.client import GenAIHubProxyClient
from gen_ai_hub.proxy.langchain.init_models import catalog
from pydantic import model_validator

from llm_commons._deprecation import deprecation_warning_once
from llm_commons.langchain.proxy.openai import ChatOpenAI, OpenAIEmbeddings, init_chat_model, init_embedding_model

PREFIX = 'AICORE_LLM'
DEFAULT_HOME = os.path.expanduser('~/.aicore_llm')

CREDENTIAL_VALUES_AICORE = CREDENTIAL_VALUES + [
    CredentialsValue(name='api_base', transform_fn=lambda url: url.rstrip('/') +
                     ('' if url.endswith('/v2') else '/v2')),
]


@proxy_clients.register('aicore')
class AICoreProxyClient(GenAIHubProxyClient):
    api_base: str | None = None

    # pylint: disable=no-self-argument
    def __init__(self, *args, **kwargs):
        deprecation_warning_once('AICoreProxyClient was renamed to GenAIHubProxyClient '
                                 'and move to gen_ai_hub.proxy.GenAIHubProxyClient.')
        super().__init__(*args, **kwargs)

    @model_validator(mode='before')
    @classmethod
    def init_client(cls, data: Any) -> Any:
        if isinstance(data, dict):
            if data.get('ai_core_client', None) is not None:
                return data
            kwargs = fetch_credentials(
                prefix=PREFIX,
                home=cls.get_home(),
                cred_values=CREDENTIAL_VALUES_AICORE,
                vcap_service_name='aicore',
            )
            for name in ['api_base', 'base_url', 'auth_url', 'client_id', 'client_secret', 'resource_group']:
                value = data.get(name, kwargs.get(name, cls.default_values.get(name, None)))
                if value is not None:
                    kwargs[name] = value
            if kwargs.get('api_base', None) is not None and kwargs.get('base_url', None) is None:
                kwargs['base_url'] = kwargs.pop('api_base')
            else:
                kwargs.pop('api_base')
            data['ai_core_client'] = AICoreV2Client.from_env(**kwargs)
        return data

    @staticmethod
    def get_home():
        return pathlib.Path(os.environ.get(f'{PREFIX}_HOME', DEFAULT_HOME)).expanduser()


try:
    import llm_commons.langchain.proxy as _
except ImportError:
    pass
