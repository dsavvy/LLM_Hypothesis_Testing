import json as jsonlib
from typing import Any, Optional
from warnings import warn

import cohere
import requests
from cohere.error import CohereAPIError, CohereConnectionError, CohereError
from gen_ai_hub.proxy.core.proxy_clients import BaseProxyClient, get_proxy_client
from gen_ai_hub.proxy.core.utils import NOT_GIVEN, NotGiven, kwargs_if_set
from requests.adapters import HTTPAdapter
from urllib3 import Retry


class Client(cohere.Client):

    def __init__(
            self,
            # api_key: str = None,  # -> will be force to be None
            num_workers: int = 64,
            request_dict: dict = {},
            # check_api_key: bool = True,  # -> will be force to be False
            # client_name: Optional[str] = None,  # -> will be force to be None
            max_retries: int = 3,
            timeout: int = 120,
            # api_url: Optional[str] = None, # -> will be force to be None
            proxy_client: Optional[BaseProxyClient] = None,
            deployment_id: str | None | NotGiven = NOT_GIVEN,
            model_name: str | None | NotGiven = NOT_GIVEN,
            config_id: str | None | NotGiven = NOT_GIVEN,
            config_name: str | None | NotGiven = NOT_GIVEN,
            **kwargs):
        self.proxy_client = proxy_client or get_proxy_client()
        model_identification = kwargs_if_set(
            deployment_id=deployment_id,
            model_name=model_name,
            config_id=config_id,
            config_name=config_name,
        )
        self.deployment = self.proxy_client.select_deployment(**model_identification)
        super().__init__(api_key=None,
                         num_workers=num_workers,
                         request_dict=request_dict,
                         check_api_key=False,
                         client_name=None,
                         max_retries=max_retries,
                         timeout=timeout,
                         api_url=None)

    def _request(self, endpoint, json=None, files=None, method='POST', stream=False, params=None) -> Any:
        headers = self.proxy_client.request_header
        if json:
            headers['Content-Type'] = 'application/json'
        url = self.deployment.prediction_url
        if json:
            json.update(self.deployment.additional_request_body_kwargs())
        with requests.Session() as session:
            retries = Retry(
                total=self.max_retries,
                backoff_factor=0.5,
                allowed_methods=['POST', 'GET'],
                status_forcelist=cohere.RETRY_STATUS_CODES,
                raise_on_status=False,
            )
            session.mount('https://', HTTPAdapter(max_retries=retries))
            session.mount('http://', HTTPAdapter(max_retries=retries))
            if stream:
                return session.request(method, url, headers=headers, json=json, **self.request_dict, stream=True)

            try:
                response = session.request(
                    method,
                    url,
                    headers=headers,
                    json=json,
                    files=files,
                    timeout=self.timeout,
                    params=params,
                    **self.request_dict,
                )
            except requests.exceptions.ConnectionError as e:
                raise CohereConnectionError(str(e)) from e
            except requests.exceptions.RequestException as e:
                raise CohereError(f'Unexpected exception ({e.__class__.__name__}): {e}') from e

            try:
                json_response = response.json()
            except jsonlib.decoder.JSONDecodeError:  # CohereAPIError will capture status
                raise CohereAPIError.from_response(response, message=f'Failed to decode json body: {response.text}')

            self._check_response(json_response, response.headers, response.status_code)
        return json_response
