from __future__ import annotations

from typing import Dict, List, Optional
from warnings import warn

import requests
from aiohttp import ClientSession
from gen_ai_hub.proxy.core.proxy_clients import BaseProxyClient, get_proxy_client
from gen_ai_hub.proxy.core.utils import NOT_GIVEN, NotGiven, kwargs_if_set
from text_generation import AsyncClient as AsyncClient_
from text_generation import Client as Client_
from text_generation.errors import parse_error
from text_generation.types import Parameters, Request, Response


class Client(Client_):

    def __init__(
            self,
            proxy_client: Optional[BaseProxyClient] = None,
            deployment_id: str | None | NotGiven = NOT_GIVEN,
            model_name: str | None | NotGiven = NOT_GIVEN,
            config_id: str | None | NotGiven = NOT_GIVEN,
            config_name: str | None | NotGiven = NOT_GIVEN,
            headers: Optional[Dict[str, str]] = None,
            cookies: Optional[Dict[str, str]] = None,  # this
            timeout: int = 20,
            **kwargs):
        self.proxy_client = proxy_client or get_proxy_client()
        model_identification = kwargs_if_set(
            deployment_id=deployment_id,
            model_name=model_name,
            config_id=config_id,
            config_name=config_name,
        )
        self.deployment = self.proxy_client.select_deployment(**model_identification)
        self._headers = None
        super().__init__(
            base_url=self.deployment.prediction_url,
            headers=headers,
            cookies=cookies,
            timeout=timeout,
        )

    @property
    def headers(self):
        return {**(self._headers or {}), **self.proxy_client.request_header}

    @headers.setter
    def headers(self, value):
        self._header = value

    def generate(
        self,
        prompt: str,
        do_sample: bool = False,
        max_new_tokens: int = 20,
        best_of: Optional[int] = None,
        repetition_penalty: Optional[float] = None,
        return_full_text: bool = False,
        seed: Optional[int] = None,
        stop_sequences: Optional[List[str]] = None,
        temperature: Optional[float] = None,
        top_k: Optional[int] = None,
        top_p: Optional[float] = None,
        truncate: Optional[int] = None,
        typical_p: Optional[float] = None,
        watermark: bool = False,
        decoder_input_details: bool = False,
    ) -> Response:
        """
        Given a prompt, generate the following text

        Args:
            prompt (`str`):
                Input text
            do_sample (`bool`):
                Activate logits sampling
            max_new_tokens (`int`):
                Maximum number of generated tokens
            best_of (`int`):
                Generate best_of sequences and return the one if the highest token logprobs
            repetition_penalty (`float`):
                The parameter for repetition penalty. 1.0 means no penalty. See [this
                paper](https://arxiv.org/pdf/1909.05858.pdf) for more details.
            return_full_text (`bool`):
                Whether to prepend the prompt to the generated text
            seed (`int`):
                Random sampling seed
            stop_sequences (`List[str]`):
                Stop generating tokens if a member of `stop_sequences` is generated
            temperature (`float`):
                The value used to module the logits distribution.
            top_k (`int`):
                The number of highest probability vocabulary tokens to keep for top-k-filtering.
            top_p (`float`):
                If set to < 1, only the smallest set of most probable tokens with probabilities that add up to `top_p` or
                higher are kept for generation.
            truncate (`int`):
                Truncate inputs tokens to the given size
            typical_p (`float`):
                Typical Decoding mass
                See [Typical Decoding for Natural Language Generation](https://arxiv.org/abs/2202.00666) for more information
            watermark (`bool`):
                Watermarking with [A Watermark for Large Language Models](https://arxiv.org/abs/2301.10226)
            decoder_input_details (`bool`):
                Return the decoder input token logprobs and ids

        Returns:
            Response: generated response
        """
        # Validate parameters
        parameters = Parameters(
            best_of=best_of,
            details=True,
            do_sample=do_sample,
            max_new_tokens=max_new_tokens,
            repetition_penalty=repetition_penalty,
            return_full_text=return_full_text,
            seed=seed,
            stop=stop_sequences if stop_sequences is not None else [],
            temperature=temperature,
            top_k=top_k,
            top_p=top_p,
            truncate=truncate,
            typical_p=typical_p,
            watermark=watermark,
            decoder_input_details=decoder_input_details,
        )
        request = Request(inputs=prompt, stream=False, parameters=parameters)
        try:
            request = request.model_dump()
        except:
            request = request.dict()
        request.update(self.deployment.additional_request_body_kwargs())
        resp = requests.post(
            self.deployment.prediction_url,
            json=request,
            headers=self.headers,
            cookies=self.cookies,
            timeout=self.timeout,
        )
        payload = resp.json()
        if resp.status_code != 200:
            raise parse_error(resp.status_code, payload)
        return Response(**payload)


class AsyncClient(AsyncClient_):
    """Asynchronous Client to make calls to a text-generation-inference instance

     Example:

     ```python
     >>> from text_generation import AsyncClient

     >>> client = AsyncClient("https://api-inference.huggingface.co/models/bigscience/bloomz")
     >>> response = await client.generate("Why is the sky blue?")
     >>> response.generated_text
     ' Rayleigh scattering'

     >>> result = ""
     >>> async for response in client.generate_stream("Why is the sky blue?"):
     >>>     if not response.token.special:
     >>>         result += response.token.text
     >>> result
    ' Rayleigh scattering'
     ```
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_base: Optional[str] = None,
        auth_url: Optional[str] = None,
        resource_group: Optional[str] = None,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        proxy_client: Optional[BaseProxyClient] = None,
        deployment_id: str = None,
        config_name: str = None,
        config_id: str = None,
        model_name: str = None,
        headers: Optional[Dict[str, str]] = None,
        cookies: Optional[Dict[str, str]] = None,  # this
        timeout: int = 20,
    ):
        self.proxy_client = proxy_client or get_proxy_client()
        model_identification = kwargs_if_set(
            deployment_id=deployment_id,
            model_name=model_name,
            config_id=config_id,
            config_name=config_name,
        )
        self.deployment = self.proxy_client.select_deployment(**model_identification)
        self._headers = None
        super().__init__(
            base_url=self.deployment.prediction_url,
            headers=headers,
            cookies=cookies,
            timeout=timeout,
        )

    @property
    def headers(self):
        return {**(self._headers or {}), **self.proxy_client.request_header}

    @headers.setter
    def headers(self, value):
        self._header = value

    async def generate(
        self,
        prompt: str,
        do_sample: bool = False,
        max_new_tokens: int = 20,
        best_of: Optional[int] = None,
        repetition_penalty: Optional[float] = None,
        return_full_text: bool = False,
        seed: Optional[int] = None,
        stop_sequences: Optional[List[str]] = None,
        temperature: Optional[float] = None,
        top_k: Optional[int] = None,
        top_p: Optional[float] = None,
        truncate: Optional[int] = None,
        typical_p: Optional[float] = None,
        watermark: bool = False,
        decoder_input_details: bool = False,
    ) -> Response:
        """
        Given a prompt, generate the following text asynchronously

        Args:
            prompt (`str`):
                Input text
            do_sample (`bool`):
                Activate logits sampling
            max_new_tokens (`int`):
                Maximum number of generated tokens
            best_of (`int`):
                Generate best_of sequences and return the one if the highest token logprobs
            repetition_penalty (`float`):
                The parameter for repetition penalty. 1.0 means no penalty. See [this
                paper](https://arxiv.org/pdf/1909.05858.pdf) for more details.
            return_full_text (`bool`):
                Whether to prepend the prompt to the generated text
            seed (`int`):
                Random sampling seed
            stop_sequences (`List[str]`):
                Stop generating tokens if a member of `stop_sequences` is generated
            temperature (`float`):
                The value used to module the logits distribution.
            top_k (`int`):
                The number of highest probability vocabulary tokens to keep for top-k-filtering.
            top_p (`float`):
                If set to < 1, only the smallest set of most probable tokens with probabilities that add up to `top_p` or
                higher are kept for generation.
            truncate (`int`):
                Truncate inputs tokens to the given size
            typical_p (`float`):
                Typical Decoding mass
                See [Typical Decoding for Natural Language Generation](https://arxiv.org/abs/2202.00666) for more information
            watermark (`bool`):
                Watermarking with [A Watermark for Large Language Models](https://arxiv.org/abs/2301.10226)
            decoder_input_details (`bool`):
                Return the decoder input token logprobs and ids

        Returns:
            Response: generated response
        """
        # Validate parameters
        parameters = Parameters(
            best_of=best_of,
            details=True,
            decoder_input_details=decoder_input_details,
            do_sample=do_sample,
            max_new_tokens=max_new_tokens,
            repetition_penalty=repetition_penalty,
            return_full_text=return_full_text,
            seed=seed,
            stop=stop_sequences if stop_sequences is not None else [],
            temperature=temperature,
            top_k=top_k,
            top_p=top_p,
            truncate=truncate,
            typical_p=typical_p,
            watermark=watermark,
        )
        request = Request(inputs=prompt, stream=False, parameters=parameters)
        try:
            request = request.model_dump()
        except:
            request = request.dict()
        request.update(self.deployment.additional_request_body_kwargs())
        async with ClientSession(headers=self.headers, cookies=self.cookies, timeout=self.timeout) as session:
            async with session.post(self.base_url, json=request) as resp:
                payload = await resp.json()

                if resp.status != 200:
                    raise parse_error(resp.status, payload)
                return Response(**payload)
