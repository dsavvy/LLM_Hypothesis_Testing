from __future__ import annotations

from typing import Optional

from gen_ai_hub.proxy.langchain.init_models import catalog
from packaging import version

from llm_commons import _openai_is_below_1_0_0

if _openai_is_below_1_0_0:
    from .openai_v0 import ChatCompletion, Completion, Embedding
    __all__ = ('ChatCompletion', 'Completion', 'Embedding')
else:
    from gen_ai_hub.proxy.native.openai import _global_client
    from gen_ai_hub.proxy.native.openai.clients import AsyncOpenAI, OpenAI
    __all__ = ('OpenAI', 'AsyncOpenAI', '_global_client')

    def __getattr__(name: str):
        if name in ('completions', 'chat', 'embeddings'):
            return getattr(_global_client.client, name)
        else:
            return locals().get(name)
