from .proxy_completion import ChatCompletion, Completion
from .proxy_embedding import Embedding

__all__ = ['ChatCompletion', 'Completion', 'Embedding']

DEFAULT_API_VERSION = '2023-05-15'
