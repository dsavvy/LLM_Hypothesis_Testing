from openai import util
from openai.api_resources.abstract.engine_api_resource import EngineAPIResource
from openai.openai_response import OpenAIResponse

from llm_commons.btp_llm.client import BTPDeployment

MAX_TIMEOUT = 20


class ProxyEngineAPIResource(EngineAPIResource):
    OBJECT_NAME = '???'

    @classmethod
    def create(
        cls,
        api_key=None,
        api_base=None,
        api_type=None,
        request_id=None,
        api_version=None,
        organization=None,
        **params,
    ):
        proxy_deployment = params.pop('_deployment', None)
        (
            deployment_id,
            engine,
            timeout,
            stream,
            headers,
            request_timeout,
            typed_api_type,
            requestor,
            url,
            params,
        ) = cls._EngineAPIResource__prepare_create_request(api_key, api_base, api_type, api_version, organization,
                                                           **params)
        if isinstance(proxy_deployment, BTPDeployment):
            url = f'?api-version={requestor.api_version}'
        else:
            url = '/' + cls.OBJECT_NAME.replace('.', '/') + f'?api-version={requestor.api_version}'
        if proxy_deployment:
            params.update(proxy_deployment.additional_request_body_kwargs())
        response, _, api_key = requestor.request(
            'post',
            url,
            params=params,
            headers=headers,
            stream=stream,
            request_id=request_id,
            request_timeout=request_timeout,
        )
        if stream:
            # must be an iterator
            assert not isinstance(response, OpenAIResponse)
            return (util.convert_to_openai_object(
                line,
                api_key,
                api_version,
                organization,
                engine=engine,
                plain_old_data=cls.plain_old_data,
            ) for line in response)
        else:
            obj = util.convert_to_openai_object(
                response,
                api_key,
                api_version,
                organization,
                engine=engine,
                plain_old_data=cls.plain_old_data,
            )

            if timeout is not None:
                obj.wait(timeout=timeout or None)

        return obj

    @classmethod
    async def acreate(
        cls,
        api_key=None,
        api_base=None,
        api_type=None,
        request_id=None,
        api_version=None,
        organization=None,
        **params,
    ):
        proxy_deployment = params.pop('_deployment', None)
        (
            deployment_id,
            engine,
            timeout,
            stream,
            headers,
            request_timeout,
            typed_api_type,
            requestor,
            url,
            params,
        ) = cls._EngineAPIResource__prepare_create_request(api_key, api_base, api_type, api_version, organization,
                                                           **params)
        if isinstance(proxy_deployment, BTPDeployment):
            url = f'?api-version={requestor.api_version}'
        else:
            url = '/' + cls.OBJECT_NAME.replace('.', '/') + f'?api-version={requestor.api_version}'
        if proxy_deployment:
            params.update(proxy_deployment.additional_request_body_kwargs())
        response, _, api_key = await requestor.arequest(
            'post',
            url,
            params=params,
            headers=headers,
            stream=stream,
            request_id=request_id,
            request_timeout=request_timeout,
        )

        if stream:
            # must be an iterator
            assert not isinstance(response, OpenAIResponse)
            return (util.convert_to_openai_object(
                line,
                api_key,
                api_version,
                organization,
                engine=engine,
                plain_old_data=cls.plain_old_data,
            ) async for line in response)
        else:
            obj = util.convert_to_openai_object(
                response,
                api_key,
                api_version,
                organization,
                engine=engine,
                plain_old_data=cls.plain_old_data,
            )

            if timeout is not None:
                await obj.await_(timeout=timeout or None)

        return obj
